# MarketLens — AI Market Research Analyst

MarketLens is a portfolio-grade AI research workspace for US equities (NYSE/Nasdaq). It combines market data, SEC filing/company facts, dated news where available, multiple specialist research tasks, genuine MCP integrations, and optional browser voice. Reports include traceable sources, dates, explicit data freshness, risks, and unknowns.

**Research only:** MarketLens does not connect to brokerages, place trades, or provide personalized buy/sell instructions. Fixture/demo data is synthetic and must never be described as current market data.

## 1. Read the build specifications

Before implementation, Claude Code should read, in order:

1. `CLAUDE_CODE_MASTER.md`
2. `architecture.md`
3. `PRD.md`
4. `MCP_TOOLS.md`
5. `VOICE_AND_AGENTS.md`
6. `EVALUATION.md`

The master file contains build rules, phases, safety constraints and the definition of done. The other documents define contracts in more detail.

## 2. Official documentation references

Consult current docs before locking package versions or writing framework-specific code:

- Next.js App Router installation: https://nextjs.org/docs/app/getting-started/installation
- LiveKit voice-agent quickstart: https://docs.livekit.io/agents/start/voice-ai/
- LiveKit agent workflows: https://docs.livekit.io/agents/logic/workflows/
- LiveKit MCP integration: https://docs.livekit.io/agents/logic/tools/mcp/
- Official MCP Python SDK: https://py.sdk.modelcontextprotocol.io/
- Alpha Vantage API documentation: https://www.alphavantage.co/documentation/
- SEC EDGAR APIs: https://www.sec.gov/search-filings/edgar-application-programming-interfaces
- SEC fair-access guidance: https://www.sec.gov/os/accessing-edgar-data

The LiveKit documentation currently describes first-class MCP integration for Python Agents and recommends explicit MCP toolset IDs instead of deprecated `mcp_servers` parameters. The official MCP Python SDK documentation describes supported transports including stdio and Streamable HTTP. Verify details against package versions actually installed.

## 3. Planned development requirements

- Node.js 20.9 or newer (confirm against current Next.js requirements when implementing).
- `pnpm` package manager.
- Python 3.11+ recommended; use the minimum common supported by selected LiveKit Agents, MCP and FastAPI versions.
- `uv` recommended for Python environment/dependency management.
- Git.
- No Docker required for local development.
- Optional API credentials for live market data, LLM research and browser voice.

## 4. Environment configuration

Create `.env.example` with all variable names below and safe placeholder values. Load actual secrets from a local, ignored `.env` file or environment. Never commit real credentials. Validate variables on startup and expose configuration presence only, not values, through health/status endpoints.

### Core

```dotenv
APP_ENV=development
APP_MODE=demo
DATA_MODE=fixtures
LLM_MODE=fixture
DATABASE_URL=sqlite:///./data/marketlens.db
BACKEND_HOST=127.0.0.1
BACKEND_PORT=8000
FRONTEND_ORIGIN=http://localhost:3000
NEXT_PUBLIC_BACKEND_URL=http://localhost:8000
LOG_LEVEL=INFO
```

### LLM — required for live AI synthesis

```dotenv
OPENAI_API_KEY=
OPENAI_MODEL=
OPENAI_TIMEOUT_SECONDS=45
LLM_MAX_CALLS_PER_RUN=8
LLM_MODE=fixture
```

Model names are provider-controlled and can change; choose a currently supported model and set it in `OPENAI_MODEL`. Do not hardcode the key or model across modules. Fixture mode must not attempt remote calls. If the implemented provider supports multiple vendors, document each additional adapter and key, but do not add providers just for breadth.

### Market data — optional live mode

```dotenv
MARKET_DATA_PROVIDER=alpha_vantage
ALPHA_VANTAGE_API_KEY=
MARKET_DATA_TIMEOUT_SECONDS=15
MARKET_DATA_CACHE_TTL_SECONDS=900
MARKET_DATA_MAX_RETRIES=2
```

Use Alpha Vantage only for endpoints enabled by the supplied plan. Do not assume a free key includes real-time data or every news/fundamentals endpoint. If a capability is unavailable, show it as unavailable; do not silently use old fixtures in live mode.

### SEC EDGAR

```dotenv
SEC_USER_AGENT=MarketLens/0.1 contact=your-email@example.com
SEC_TIMEOUT_SECONDS=15
SEC_CACHE_TTL_SECONDS=3600
SEC_MAX_CONCURRENT_REQUESTS=2
```

Supply a meaningful identifying User-Agent as required by SEC guidance, obey fair-access rules, and cache responses. The exact concurrency/rate policy should be conservative and documented.

### LiveKit voice — optional

```dotenv
VOICE_MODE=disabled
LIVEKIT_URL=
LIVEKIT_API_KEY=
LIVEKIT_API_SECRET=
LIVEKIT_AGENT_NAME=marketlens-voice-agent
VOICE_SESSION_TTL_SECONDS=600
```

Set `VOICE_MODE` to the implemented supported mode only after current LiveKit documentation is checked. Voice requires valid LiveKit credentials and the configured speech/LLM provider credentials. Never expose `LIVEKIT_API_SECRET` to the browser. If voice is not configured, text mode must remain functional.

### MCP and security limits

```dotenv
MCP_TRANSPORT=stdio
MCP_TOOL_CALL_TIMEOUT_SECONDS=20
MAX_RESEARCH_STEPS=12
MAX_PROVIDER_CALLS=20
MAX_PARALLEL_SPECIALISTS=3
MAX_REPORT_CHARS=18000
ACTION_CONFIRMATION_TTL_SECONDS=300
```

The implemented config may add provider-specific settings; keep `.env.example` aligned with the actual configuration parser and README.

## 5. Local run commands — target interface

Claude Code must make the commands below work, or update this section and all scripts consistently if the final repository uses slightly different names.

### Install

```bash
# From the repository root
pnpm install
uv sync --project services/backend
uv sync --project services/mcp_market_data
uv sync --project services/mcp_research_sources
uv sync --project services/mcp_research_workspace
```

If the MCP servers share a single Python project, use one uv sync command instead and document that structure. Do not create multiple redundant Python environments without reason.

### Configure

```bash
cp .env.example .env
# Edit .env. Keep all real values local and uncommitted.
```

Expected default should be `APP_MODE=demo`, `DATA_MODE=fixtures`, `LLM_MODE=fixture`, `VOICE_MODE=disabled`, making the test/demo workflow work without external credentials.

### Run the app

Use three terminals until a tested root orchestration script is available:

```bash
# Terminal 1 — backend API
uv run --project services/backend uvicorn app.main:app --reload --host 127.0.0.1 --port 8000

# Terminal 2 — Next.js frontend
pnpm --dir apps/web dev

# Terminal 3 — optional LiveKit agent worker; only after configuring voice
uv run --project services/backend python -m app.voice.worker dev
```

These are target commands, not a claim that code already exists. Claude Code must make the module paths and commands match the generated repository. MCP server processes are launched by the backend MCP client as needed, unless the implementation documents a different tested process manager.

Visit `http://localhost:3000`. Backend health should be available at `http://127.0.0.1:8000/api/health`.

## 6. Run tests

Target commands, to be finalized to match actual scripts:

```bash
# Python unit, API and MCP integration tests
uv run --project services/backend pytest

# TypeScript lint/typecheck/build
pnpm --dir apps/web lint
pnpm --dir apps/web typecheck
pnpm --dir apps/web build

# Deterministic evaluation runner
uv run --project services/backend python scripts/run_evaluation.py
```

If the evaluation script lives at the repository root, update the command to the actual path. The default test suite must not require paid provider keys or call live APIs. Credentialed integration checks should be separately marked and reported as skipped when not configured.

## 7. Demo path

1. Open Research Home with no API credentials; UI must display `DEMO FIXTURES` prominently.
2. Select `AAPL` and run the seeded prompt: “Review recent price movement, company fundamentals, news context and key risks.”
3. Show specialist progress and MCP tool calls.
4. Open one numeric claim and inspect its source evidence, timestamp, period and calculation inputs.
5. Point out an explicit unknown or missing source category to show that the app does not make up facts.
6. Click **Save brief**, inspect the confirmation panel, approve it, and then open the saved brief from history.
7. Open watchlist, add/remove a demo symbol through the confirmation flow.
8. If voice is configured, start a LiveKit session and ask a follow-up such as “What are the strongest risks in this report?” Otherwise explain the text-only path and show voice setup status; do not pretend voice is active.
9. Show the evaluation output and explain that it uses a synthetic test dataset rather than real customer/business results.

## 8. Data provider behavior and limitations

### Alpha Vantage

- Use provider documentation to map implemented endpoint names, parameters, plan dependencies, quota behavior and response schemas.
- Treat API rate limits and subscription-specific endpoint availability as runtime capability state.
- Quote/series/news results must include provider timestamps and retrieval timestamps separately where both exist.
- A rate-limit response should lead to a safe status and bounded retry/backoff, not a loop.

### SEC EDGAR

- SEC public data APIs provide submissions and XBRL company facts without an API key, but automated clients must follow SEC access policies.
- Include a meaningful `SEC_USER_AGENT`; use respectful rate limiting and response caching.
- Preserve official URLs, filing forms, filing dates, reporting periods, accession/document identifiers and retrieval timestamps.
- Use the official SEC API metadata and documented access patterns rather than unbounded scraping.

### Fixture mode

- Fixture mode is intentionally deterministic. Data timestamps may be historical or illustrative; all fixtures must be labeled synthetic/demo in both UI and API.
- Do not display fictional observations as current exchange prices.
- Never mix live values and fixture values in a report without explicitly labeling each item and the mixed-source limitation.

## 9. Troubleshooting expectations

- **`OPENAI_API_KEY` missing:** fixture LLM remains available; live synthesis is disabled with clear setup guidance.
- **Market-data key missing:** fixture data works; live market capabilities report disabled.
- **Alpha Vantage quota/plan limits:** display the unavailable capability and last successful fetch; do not say “current price” if data is stale.
- **SEC request denied/rate-limited:** use bounded backoff/cache, disclose filing source outage and continue only with other sources if clearly marked partial.
- **LiveKit absent:** voice is disabled but text mode works.
- **MCP child process fails:** report server name/tool category and recoverable action, keep secrets out of logs.
- **SQLite schema issue:** give migration/backup instructions; do not silently delete the database.
- **Build/test fails:** review `PROJECT_STATUS.md` and rerun after the fix; do not mark a gate passed without evidence.

## 10. Privacy and safety disclosure

- Do not request real brokerage credentials, account statements or sensitive personal information.
- Avoid saving raw voice audio. Provide clear transcript retention behavior.
- Do not log API keys or authorization headers.
- No trades, no brokerage account integration, no personalized financial recommendations.
- User can verify claims against source links and as-of dates; the product is informational and may have data gaps.

## 11. Deployment notes

The first release is a local single-user portfolio demo. Any public deployment requires a separate hardening pass: authentication, per-user data isolation, secure session handling, rate limiting, stricter CORS, key management, retention/deletion policy, provider-terms review, monitoring, and abuse protection. Do not expose the local no-auth backend to the public internet. No Docker is required for the MVP; deployment can be documented as a future extension after local correctness gates pass.

## 12. Portfolio narrative

Recommended portfolio headline:

> **MarketLens — Evidence-grounded AI Equity Research with Multi-Agent Orchestration, MCP Tools, and Voice AI**

Discuss the project honestly as a prototype evaluated using synthetic scenarios. Interview story arc:
1. Problem: research is spread across market data, filings and news; generic answers can be hard to verify.
2. Product choice: source-grounded briefs, dates, risks/unknowns, and evidence inspector.
3. Architecture: shared research workflow, specialist tasks, three MCP servers, provider adapters and LiveKit voice.
4. Safety: no-trading scope, untrusted retrieved data, deterministic metrics and confirmation-gated writes.
5. Evaluation: deterministic test suite, source grounding, tool correctness, numerical accuracy, unauthorized-write checks and latency measurement.
6. Trade-offs: fixture mode, limited initial symbol set, provider plan dependence, and future work separated from MVP.

Do not claim revenue, adoption, time saved, model accuracy or investment performance unless those outcomes have actually been measured with valid data.
