# MarketLens — Architecture and Phased Implementation Plan

**Product:** MarketLens, an AI market-research analyst for US equities (NYSE/Nasdaq)  
**Primary interaction:** Text + browser voice  
**Initial market-data sources:** Alpha Vantage (optional, plan-dependent) + SEC EDGAR public data + deterministic fixtures  
**Implementation languages:** TypeScript/Node.js and Python  
**Local database:** SQLite  
**Last documentation review:** 2026-10-09

## 1. Architecture principles

1. **Evidence before explanation.** Retrieve structured data and source documents before generating interpretations. Never ask an LLM to invent missing prices, financial metrics, dates, or citations.
2. **MCP is a real boundary.** The three servers are independent MCP processes. A client must list/discover their tools and invoke them through the current official MCP SDK. A direct function call alone does not count as MCP integration.
3. **One research workflow, two interaction modes.** Text and voice invoke the same `ResearchWorkflowService`; avoid duplicating financial logic in the frontend or voice conversation prompt.
4. **Constrained multi-agent orchestration.** Use a supervisor plus specialist research steps with defined inputs/outputs. Specialists are bounded tasks that return typed findings; they do not freely call one another or write persistent state.
5. **Deterministic arithmetic and business rules.** Price changes, period comparisons, freshness, symbol validation, missing-field checks, permissions, duplicate detection and persistence are code, not LLM judgments.
6. **Read-only financial environment.** No broker access, order execution or trading recommendation engine.
7. **Graceful configuration.** Fixture mode must work offline. Live market data, real LLM analysis and voice are separately configurable capabilities.
8. **Observable by design.** Every run produces a trace of steps, MCP calls, source IDs, timing, errors and final status without leaking secrets.

## 2. System context

```mermaid
flowchart TD
  U[User: text or voice] --> W[Next.js web application]
  W -->|HTTP JSON| B[FastAPI backend]
  W <-->|WebRTC / LiveKit room| LK[LiveKit voice session]
  LK --> VA[Voice agent adapter]
  VA --> RW[ResearchWorkflowService]
  B --> RW
  RW --> ORCH[Research supervisor / task orchestrator]
  ORCH --> MDP[MCP client gateway]
  MDP --> MD[Market Data MCP server]
  MDP --> RS[Research Sources MCP server]
  MDP --> WS[Research Workspace MCP server]
  MD --> AV[Alpha Vantage adapter]
  RS --> SEC[SEC EDGAR adapter]
  RS --> NEWS[News provider adapter / fixture]
  MD --> FIX[Fixture provider]
  RS --> FIX
  WS --> DB[(SQLite)]
  B --> DB
  RW --> DB
  ORCH --> LLM[LLM provider adapter]
  VA --> LLM
  RW --> EV[Evidence ledger and audit records]
  EV --> DB
```

The voice layer is an interaction adapter, not a second copy of the research system. The browser obtains an expiring room token from the backend only when voice configuration is enabled. The token endpoint must never return the LiveKit API secret. The voice agent calls a bounded `run_company_research` tool that delegates to the same service used by text mode.

## 3. Components and responsibilities

### 3.1 Web app — `apps/web`

Responsibilities:
- Research request form with symbol/company selector and a natural-language research question.
- Text interaction always available; voice enabled only when backend health/configuration reports it is ready.
- Research run view with status, progress, specialist steps, source freshness and recoverable errors.
- Research brief layout with evidence links, metric date labels and explicit limitations.
- Evidence inspector, watchlist, saved briefs and confirmation UI for persistent actions.
- Display of active data mode (`LIVE DATA` / `DEMO FIXTURES`) and timestamp of latest provider data.
- Accessible behavior for keyboard users, microphone permission denial, network interruption and mobile layouts.

Non-responsibilities:
- Provider credentials, market-data calls, LLM calls, MCP server access, financial calculations, write authorization, API retries, or truth/safety decisions.

### 3.2 FastAPI backend — `services/backend`

Suggested internal modules:

```text
backend/
  app/main.py
  app/config.py
  app/api/health.py
  app/api/research.py
  app/api/briefs.py
  app/api/watchlist.py
  app/api/voice.py
  app/domain/models.py
  app/domain/errors.py
  app/services/research_workflow.py
  app/services/research_orchestrator.py
  app/services/evidence_ledger.py
  app/services/action_confirmation.py
  app/services/analytics.py
  app/agents/supervisor.py
  app/agents/market_specialist.py
  app/agents/news_specialist.py
  app/agents/fundamentals_specialist.py
  app/agents/evidence_reviewer.py
  app/providers/llm/base.py
  app/providers/llm/openai_provider.py
  app/providers/llm/fixture_provider.py
  app/mcp/client_gateway.py
  app/db/connection.py
  app/db/repositories.py
```

Implement only the minimum necessary modules. Avoid creating unused abstractions. The LLM provider adapter must expose structured-output operations with schemas and validation. `ResearchWorkflowService` owns orchestration status and persists run/evidence/tool traces. Domain models are independent of provider SDK response types.

Required initial HTTP routes (adjust naming only if OpenAPI and README stay consistent):
- `GET /api/health` — basic status, mode, version, configured capability booleans, never secrets.
- `GET /api/data-status` — provider status, latest successful retrieval, whether data is live or fixture, known limitations.
- `POST /api/research` — create and run a text research request; return `run_id` and status or structured output depending on synchronous implementation. UI should be prepared for status polling.
- `GET /api/research/{run_id}` — fetch status, steps, partial findings and errors.
- `POST /api/research/{run_id}/cancel` — cancel when safe; persist cancellation.
- `GET /api/briefs` and `GET /api/briefs/{brief_id}` — list/open saved briefs.
- `POST /api/actions/{action_id}/confirm` — confirm a pre-created proposed write, validate user/session binding, and invoke the appropriate workspace MCP write tool with a one-time approval grant.
- `GET /api/watchlist`, `POST /api/watchlist`, `DELETE /api/watchlist/{symbol}` — read/update local watchlist through service boundaries and validate symbol.
- `POST /api/voice/token` — issue short-lived LiveKit room credentials only if voice is configured; return only client-facing token and URL.

For MVP, local single-user mode is acceptable, but every write must still use server-side input validation and action confirmation. Document that local mode is not hardened for public multi-tenant deployment.

### 3.3 Research workflow and agents

The workflow is predictable even though some steps use an LLM. Recommended sequence:

1. Validate and normalize the symbol; determine request type and required evidence categories.
2. Create `ResearchRun`; append a `plan_created` event.
3. In parallel where appropriate, collect (a) market/pricing data, (b) company fundamentals/SEC evidence, and (c) news/events. Bound concurrency and total time.
4. Pass typed evidence packages to separate specialist tasks:
   - **Market Data Specialist:** summarize price/volume/time-window movement, cite retrieved series and deterministic calculations; cannot make up causal explanations.
   - **News & Events Specialist:** summarize event chronology from dated sources; label relevance as possible context unless causality is adequately supported.
   - **Fundamentals Specialist:** summarize financial metrics and periods from provider/SEC records; explain units/period comparisons.
   - **Evidence & Risk Reviewer:** review factual claims against evidence IDs, dates, coverage, source quality and contradictions. Reject or qualify unsupported claims.
5. Supervisor synthesizes validated specialist outputs into a `ResearchBrief` schema with fact/calculation/interpretation/scenario classifications, risks, unknowns, sources and timestamp metadata.
6. Validate every material claim's evidence references and every numerical result against deterministic values. Omit or downgrade claims that fail validation; do not silently retain unsupported content.
7. Persist the run and event trace. Return a complete or partial result with provider/source limitations. The run can be saved only through the explicit confirmation flow.

The first implementation may use one LLM call per specialist plus one supervisor call. Use parallel calls only where dependencies allow, bound them by a semaphore and timeout, and record model/latency/cost metadata where available. Use structured Pydantic output models. A deterministic fixture LLM implementation should return known payloads so unit and integration tests do not require an external model.

### 3.4 MCP servers

Run each server independently, over **stdio** for local development unless the current official SDK or deployment model makes another transport materially simpler:

- `services/mcp_market_data` — quote, historical prices, financial metric retrieval, deterministic calculations, provider status.
- `services/mcp_research_sources` — SEC filings/company facts, news search, source metadata and permitted filing excerpt retrieval.
- `services/mcp_research_workspace` — app-local watchlist and saved brief actions with confirmation safeguards.

Each server must declare tool descriptions and JSON input/output schema using the official MCP Python SDK. The agent/backend uses a real MCP client session and invokes tools by name. Add integration tests that spawn servers, list tools, call every tool with valid input, and verify input failures. Do not expose arbitrary filesystem, shell, SQL or URL-fetch tools to an LLM.

### 3.5 Provider adapters

**Alpha Vantage adapter:** optional live market data and news/fundamental endpoints where the user's API plan provides them. Keep the endpoint mapping in one module. Use an HTTP timeout, request limiter, TTL cache and clear error translations. Do not assume every endpoint is enabled by a free key.

**SEC EDGAR adapter:** use official `data.sec.gov` APIs (company submissions and XBRL company facts) and official filing URLs. Map ticker to CIK using the SEC-maintained company tickers mapping. Supply a meaningful `User-Agent` through `SEC_USER_AGENT`, follow SEC fair-access guidance, cache responses and limit concurrency. Do not scrape the site aggressively or try to bypass limits.

**Fixture adapter:** versioned files under `data/fixtures/`, with every record marked `is_fixture: true`, `source_mode: fixture`, source timestamp and synthetic/illustrative labels. Fixture records must use plausible structure but must not masquerade as current prices. Tests should assert that fixture mode is obvious in API payloads and UI.

**News:** use Alpha Vantage news if enabled by the selected plan. Where the plan does not provide it, return a `capability_unavailable` result or use explicitly labeled fixtures. Never silently substitute old fixtures in a live-mode report.

### 3.6 SQLite persistence

Use a single local SQLite database with repository methods, foreign keys enabled, and a stable schema. Recommended tables:

- `research_runs`: status, request, ticker, mode, start/end timestamps, failure summary.
- `research_steps`: run ID, step key, agent name, status, input/output reference or safe summary, start/end time.
- `evidence_items`: stable evidence ID, source type/name/URL, published date, period date(s), retrieved timestamp, content hash, symbol and structured payload/snippet.
- `research_claims`: run ID, claim type, text, materiality, evidence IDs, validation state.
- `tool_calls`: run ID, MCP server/tool, validated input summary, output summary, latency, status/error code and idempotency key; never persist secrets.
- `research_briefs`: final structured payload, creation time, data mode, save source/action ID.
- `watchlist_items`: symbol, company name if resolved, created/updated timestamps.
- `pending_actions`: action ID, action type, payload hash, run/user-session binding, expiration, status, confirmation time and consumed time.
- `audit_events`: ordered event names and safe metadata for writes and key safety decisions.
- Optional `provider_cache`: provider/endpoint/cache key, expiry, response payload (respect provider terms and minimize stored third-party content).

Create schema through migrations or a repeatable versioned initializer. Do not use destructive `DROP TABLE` initialization outside tests. Add indexes for run ID, symbol, and created timestamps.

### 3.7 Voice session

- Voice is an optional LiveKit interaction adapter. When enabled, the web app obtains an ephemeral room token from FastAPI and connects via the LiveKit client.
- The LiveKit worker uses the current supported Python Agents API and the chosen supported STT/LLM/TTS configuration. Read LiveKit's current official quickstart and workflow docs; do not assume an API from an older example.
- Voice exposes a narrow `run_company_research` tool which invokes the same `ResearchWorkflowService`, plus read-only helpers for retrieving the current run/brief. Persistent writes still require UI confirmation and server-side approval grants.
- For long-running research, acknowledge progress, send step status to the UI, and provide a completion/partial-result message when ready. Do not block indefinitely without user feedback.
- Voice failure must not disable text mode. If LiveKit credentials or a supported speech configuration are missing, return an explicit disabled capability status.

## 4. Data contracts

Canonical domain types should at minimum include:

- `ResearchRequest`: `symbol`, `question`, `time_horizon`, optional focus areas, requested mode, client request ID.
- `ResearchRun`: `run_id`, normalized symbol, status, created/updated/start/end timestamps, mode, ordered steps, errors, partial flag.
- `EvidenceItem`: `evidence_id`, `kind`, `source_name`, `source_url`, `retrieved_at`, optional `published_at`, `period_start`, `period_end`, `ticker`, `currency`, `units`, `is_fixture`, `data_freshness`, `payload` or concise permitted excerpt.
- `ResearchClaim`: `claim_id`, `text`, `claim_type` (`source_fact`, `calculation`, `interpretation`, `scenario`), `evidence_ids`, `validation_status`, `confidence_note` as explanatory text (not fake probability).
- `ResearchBrief`: title, ticker/company, executive summary, key metrics, movement/context, fundamentals, recent events, positive evidence, negative evidence, risks, unknowns, methodology, source references, as-of/retrieval timestamps, mode/disclaimer, claims.
- `MarketQuote`: symbol, price, currency, observed_at, provider, market state if available, is_fixture.
- `PriceBar`: symbol, interval, timestamp, open/high/low/close/volume, currency if applicable, provider, is_fixture.
- `AgentStep`, `ToolCallRecord`, `DataSourceStatus`, `WatchlistItem`, `SavedBrief`, `PendingAction`, `ConfirmationGrant`.

Use ISO-8601 timestamps with timezone. Use enums for run status, source kind, claim type, validation status and provider mode. Preserve values and currency units from the source. Make null/missing fields explicit. Do not infer market state or timestamps from the system clock.

## 5. Proposed API flow

```mermaid
sequenceDiagram
  participant User
  participant Web
  participant API as FastAPI
  participant Workflow
  participant MCP as MCP client gateway
  participant Servers as MCP servers
  participant DB as SQLite
  User->>Web: Submit ticker + research question
  Web->>API: POST /api/research
  API->>Workflow: run(request)
  Workflow->>DB: Create run(status=running)
  Workflow->>MCP: Call market/news/filing tools
  MCP->>Servers: MCP tools/call
  Servers-->>MCP: Structured data + source metadata
  MCP-->>Workflow: Normalized evidence
  Workflow->>Workflow: Specialist tasks + review + validation
  Workflow->>DB: Persist evidence, steps, claims, status
  Workflow-->>API: ResearchRun / ResearchBrief
  API-->>Web: JSON result or run ID
  Web-->>User: Evidence-backed report + data mode
  User->>Web: Click Save report
  Web->>API: Confirm pending action
  API->>MCP: MCP call save_research_brief with one-time grant
  MCP->>DB: Validate grant + persist brief
  MCP-->>API: Saved brief ID
  API-->>Web: Confirm actual saved state
```

## 6. Phased implementation — each phase has a gate

### Phase 0 — Product definition and build contract

**Goal:** Define the first useful research workflow, not an unbounded finance assistant.

**Description:**
- Read all specification files and reconcile contracts before coding.
- Create `PROJECT_STATUS.md` and a short decision log.
- Define a single happy-path request: “Research AAPL over the last 3 months; explain notable movement; review recent news and latest available filings; list risks and unknowns.”
- Define a deliberately limited symbol set for fixtures (e.g. AAPL, MSFT, NVDA) and one default demo report.
- Define the KPI tree and evaluation gate in `EVALUATION.md`.
- Add a concise architecture diagram to the README (can link to this file).

**Outcome:** Product scope, contracts and acceptance criteria are fixed before framework-generated code lands.

**Gate / acceptance criteria:**
- Every MVP feature is in `PRD.md` and every tool is in `MCP_TOOLS.md`.
- No-trading restriction is stated in the UI copy and server-side code comments/policies.
- The first fixture-mode report can be described using known fixture evidence; missing evidence behavior is explicit.

### Phase 1 — Foundation and deterministic text experience

**Goal:** Establish a working frontend/backend contract and a testable vertical slice before live providers or voice.

**Description:**
- Generate the Next.js app using current recommended TypeScript/App Router defaults; use `pnpm` and lockfile.
- Create FastAPI app, configuration parser, typed domain models, SQLite initialization and `/api/health`.
- Add fixture data and `FixtureProvider` / `FixtureLLMProvider`.
- Build research home, result view, evidence inspector shell, watchlist shell and visible DEMO FIXTURES banner.
- Implement `POST /api/research` against a deterministic orchestrator that returns a fixed but correctly sourced report.
- Add request/response validation and API error model.

**Outcome:** A locally running app can submit a research question and display a deterministic, explicitly labeled report without any external key.

**Gate / acceptance criteria:**
- Frontend start, backend start, API health, unit tests and frontend build pass.
- Fixture report renders actual fixture values and links/evidence identifiers from fixture files.
- Unknown symbols and invalid input return actionable 4xx responses.
- A provider or LLM key is not needed for fixture tests.

### Phase 2 — Provider adapters, MCP servers and persistent state

**Goal:** Replace simulated internal data calls with genuine protocol-based MCP tool calls and provider adapters.

**Description:**
- Implement three independently runnable MCP server processes using the official Python SDK.
- Implement `MarketDataProvider` interface, initial Alpha Vantage adapter, SEC EDGAR adapter, news capability detection and deterministic fixture adapter.
- Implement `MCPClientGateway` with explicit server/tool allowlist, timeouts, error translation, argument/result validation, and safe logging.
- Add provider caches and bounded rate control. Apply SEC User-Agent and fair-access guidance.
- Implement workspace repositories for watchlist and saved briefs; add schema initialization/migrations.
- Implement pending-action confirmation mechanism. A tool can only persist after the server validates a one-time, unexpired, session/run-bound grant that was issued after a UI confirmation click.
- Add MCP integration tests that spawn actual server processes, list tools and call every exposed tool.

**Outcome:** A research request can access live provider data when configured, and all server integrations work deterministically in fixture mode. The report can be saved through an authorized MCP write call.

**Gate / acceptance criteria:**
- Every named tool in `MCP_TOOLS.md` is registered and has schema/description.
- MCP tests use MCP protocol calls, not direct service calls.
- Live-mode failures cannot silently become fixture results.
- Alpha Vantage quota errors, SEC rate limiting, malformed upstream responses and timeouts map to safe structured errors.
- Confirmation tests prove that missing, invalid, expired, reused, wrong-session and payload-mismatched grants cannot write.
- Watchlist/save changes persist through restart.

### Phase 3 — Research supervisor, specialist tasks and evidence validation

**Goal:** Create differentiated agentic reasoning that converts gathered evidence into a reliable research report.

**Description:**
- Add configured `LLMProvider` interface and an OpenAI provider with structured-output schema validation. Keep model identifiers in environment config.
- Implement supervisor planning and dedicated market, news/events, fundamentals and evidence-reviewer specialist prompts/modules.
- Gather independent evidence categories concurrently with bounded concurrency; do not fan out unbounded LLM or provider requests.
- Enforce typed JSON outputs, evidence ID requirements, deterministic calculation checks and conflict detection.
- Run a final validation pass that removes or qualifies material claims without sufficient evidence.
- Build step progress events, partial-result status, cancellation and retry behavior.
- Use `FixtureLLMProvider` for deterministic tests and reserve real-model smoke tests for configured environments.

**Outcome:** Text mode produces a genuine multi-specialist research report with traced data sources and explicit unknowns.

**Gate / acceptance criteria:**
- At least three distinct specialist roles are executed for a full report; evidence reviewer validates the supervisor output.
- Specialists have constrained responsibilities and return typed results.
- Numbers match provider/fixture data or deterministic calculations.
- Unsupported statements are rejected or marked as unverified; citations point to real evidence IDs.
- Missing source categories produce a partial report or explicit unavailable category, not fabricated content.
- Evaluation cases for contradictions, date mismatch, stale data and prompt injection pass.

### Phase 4 — Voice experience with shared research workflow

**Goal:** Allow a user to start and refine research through natural spoken conversation.

**Description:**
- Integrate LiveKit Agents using current official Python documentation. Select a supported STT/LLM/TTS or realtime-model path and pin dependencies.
- Add backend token route with short expiry and room/session scoping; never expose API secret.
- Add browser voice UI with microphone permission flows, listening/speaking/processing states, transcript, mute/end buttons, interruption handling, reconnect behavior and text fallback.
- The voice agent may call only bounded tools, especially `run_company_research`, `get_run_status`, and `get_brief_summary`; it must invoke the shared workflow.
- Forward progress safely so long research runs provide status updates; do not read the entire report aloud without asking. Speak a concise summary and invite follow-up.
- Test voice adapter independently with mocked session/events; run real speech smoke test only when credentials are configured.

**Outcome:** A user can speak a research question, hear a concise answer, view the full cited brief, and ask contextual follow-up questions.

**Gate / acceptance criteria:**
- With valid credentials, microphone-to-agent-to-research-to-spoken-summary path works in a supported browser.
- With missing voice configuration, text mode still works and voice is clearly disabled.
- Denied microphone permission, disconnects, delayed research and user interruptions are handled gracefully.
- Voice follow-up does not lose ticker/report context within a session.
- The voice agent cannot bypass write confirmations or use trading tools.

### Phase 5 — Research workspace and product-quality UX

**Goal:** Make MarketLens useful beyond a one-off answer.

**Description:**
- Complete watchlist CRUD, saved brief list/detail, rerun research, compare two periods, and source freshness UI.
- Show “as of” labels for each metric group; distinguish market observation time, filing period end, news publication time, and data retrieval time.
- Add empty/loading/partial/error states and keyboard-accessible controls.
- Add basic product analytics events in local DB or structured logs: run start/completion, report save, watchlist changes, voice connection success/failure, source category success/failure. Avoid personal data and raw secrets.
- Add a “How this analysis was prepared” section documenting sources, periods, deterministic calculations, model-generated interpretations and limitations.

**Outcome:** A polished, reusable research workspace with traceable research history.

**Gate / acceptance criteria:**
- Saved briefs survive restart and visibly retain original source timestamps and data mode.
- Watchlist operations validate symbols and are idempotent where feasible.
- All important states have accessible visible feedback.
- Product analytics do not contain API secrets or raw audio.

### Phase 6 — Evaluation, safety and regression hardening

**Goal:** Demonstrate that the product is reliable and safe under realistic edge cases.

**Description:**
- Build evaluation set of at least 40 cases from `EVALUATION.md`; include normal, missing-data, stale-data, contradictory, adversarial, provider-error and confirmation cases.
- Automate ground-truth numeric comparisons for all fixture cases.
- Measure source coverage, tool accuracy, unsupported-claim rate, run completion, partial-report behavior, latency and voice handling where configured.
- Add tests for prompt injection inside retrieved news/filing text, malformed tool arguments, duplicate writes, invalid ticker, zero previous price, provider throttling and missing credentials.
- Add security checks for secrets, CORS, excessive request body size, tool allowlists, unbounded retries and public exposure warnings.
- Run tests with credentials absent; ensure deterministic CI does not call live providers.

**Outcome:** A reproducible evaluation report, clear known limitations, and a regression suite for known failures.

**Gate / acceptance criteria:**
- All mandatory deterministic tests pass.
- Zero unauthorized persistent writes in the test suite.
- Zero knowingly fabricated numerical values and all material fixture claims trace to evidence.
- API/LLM/provider failures result in clear partial/failure output, never invented facts.
- Any threshold miss is documented; do not declare success by lowering thresholds after seeing results without a recorded rationale.

### Phase 7 — Portfolio packaging and deployment readiness

**Goal:** Make the project easy for an interviewer to evaluate in five minutes and reproducible for a developer.

**Description:**
- Complete README quickstart, `.env.example`, setup troubleshooting, commands, provider notes, architecture diagram and demo data disclosure.
- Add `scripts/seed_demo.py`, `scripts/run_evaluation.py` and a report output location (e.g. `reports/evaluation/latest.json`); ensure scripts are idempotent.
- Create a deterministic five-minute demo script and at least three screenshots or a short screen recording if the environment permits.
- Document the live voice setup and include a no-credentials text-demo path.
- Add deployment notes but do not require Docker. Clearly distinguish local single-user MVP from production multi-tenant requirements.

**Outcome:** A credible AI PM portfolio artifact with a running demo, architecture, evaluation evidence and clear limitations.

**Gate / acceptance criteria:**
- A clean setup follows README without undocumented manual steps.
- All advertised commands exist and run successfully or are explicitly marked optional/credential-gated.
- Evaluation artifact is generated from an actual run.
- Portfolio copy does not claim measured business impact that was not measured.

## 7. Cross-cutting release checklist

- [ ] All API errors use stable codes and safe human-readable messages.
- [ ] All financial numbers have units/currency and date/as-of context.
- [ ] Fixture records are labeled in API and UI.
- [ ] Every material factual claim links to an evidence ID.
- [ ] No trade execution, brokerage credentials, buy/sell recommendation or autonomous investment action exists.
- [ ] Persistent writes require server-validated one-time confirmation grants.
- [ ] Retrieved content is treated as untrusted data.
- [ ] Logs omit secrets, authorization headers, and unnecessary full transcript/audio.
- [ ] Live data, LLM and voice failures are visible and recoverable.
- [ ] Text research remains usable without voice credentials.
- [ ] README commands match actual scripts.
- [ ] `PROJECT_STATUS.md` records exact test results and known issues.

## 8. Official technical references

- LiveKit MCP integration: https://docs.livekit.io/agents/logic/tools/mcp/
- LiveKit voice-agent quickstart: https://docs.livekit.io/agents/start/voice-ai/
- LiveKit workflows: https://docs.livekit.io/agents/logic/workflows/
- Official Python MCP SDK: https://py.sdk.modelcontextprotocol.io/
- Next.js installation/App Router: https://nextjs.org/docs/app/getting-started/installation
- Alpha Vantage API documentation: https://www.alphavantage.co/documentation/
- SEC EDGAR APIs: https://www.sec.gov/search-filings/edgar-application-programming-interfaces
