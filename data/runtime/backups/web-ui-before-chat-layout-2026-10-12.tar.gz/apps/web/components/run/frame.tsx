"use client";

import type { ResearchBrief } from "@/lib/api/types";
import { naturalize, niceDate } from "@/lib/natural";

import { cn } from "../ui";

/**
 * Main-pane layout for a brief: a frozen summary bar, the scrolling brief, and the evidence
 * inspector docked beside it. Only the brief scrolls; the bar and the research bar stay put.
 */
export function BriefFrame({ bar, children, side }: { bar: React.ReactNode; children: React.ReactNode; side?: React.ReactNode }) {
  return (
    <div className="flex min-h-0 flex-1">
      <div className="min-w-0 flex-1 overflow-y-auto" data-testid="brief-scroll">
        <div className="sticky top-0 z-20 border-b border-line bg-plane/85 backdrop-blur-md">{bar}</div>
        <div className="mx-auto max-w-4xl space-y-6 px-4 pb-16 pt-6 sm:px-6">{children}</div>
      </div>
      {side}
    </div>
  );
}

/** The price and price change from the brief's key numbers, if they exist. */
function headline(brief: ResearchBrief | null | undefined) {
  const metrics = brief?.key_metrics ?? [];
  const price = metrics.find((m) => /last close|latest provider quote/i.test(m.label));
  const change = metrics.find((m) => /price change/i.test(m.label));
  return { price, change };
}

export function Headline({ brief }: { brief: ResearchBrief | null | undefined }) {
  const { price, change } = headline(brief);
  if (!price && !change) return null;
  const up = change?.display_value.startsWith("+");
  const down = change ? /^[−-]/.test(change.display_value) : false;
  return (
    <span className="inline-flex flex-wrap items-baseline gap-x-2.5">
      {price && (
        <span className="text-lg font-semibold tracking-tight tabular text-ink" title={`${price.label}, ${naturalize(price.as_of)}`}>
          {price.display_value}
        </span>
      )}
      {change && (
        <span className={cn("text-sm font-semibold tabular", up && "text-good-text", down && "text-critical-text")}>
          <span aria-hidden="true">{up ? "▲ " : down ? "▼ " : ""}</span>
          {change.display_value}
          <span className="ml-1.5 font-normal text-ink-3">{naturalize(change.as_of)}</span>
        </span>
      )}
      {price && !change && <span className="text-xs text-ink-3">as of {niceDate(price.as_of)}</span>}
    </span>
  );
}

/** Frozen bar at the top of a brief: identity, status, key price, question and actions. */
export function SummaryBar({
  symbol,
  company,
  badges,
  actions,
  headline,
  question,
}: {
  symbol: string;
  company?: string | null;
  badges?: React.ReactNode;
  actions?: React.ReactNode;
  headline?: React.ReactNode;
  question?: string | null;
}) {
  return (
    <div className="mx-auto max-w-4xl px-4 py-3 sm:px-6">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
        <h1 className="flex min-w-0 items-baseline gap-2">
          <span className="font-mono text-xl font-bold tracking-tight text-ink">{symbol}</span>
          {company && <span className="truncate text-sm font-medium text-ink-2">{company}</span>}
        </h1>
        <span className="flex flex-wrap items-center gap-1.5">{badges}</span>
        <div className="ml-auto flex flex-wrap items-center gap-2">{actions}</div>
      </div>
      <div className="mt-1.5 flex min-w-0 flex-wrap items-baseline gap-x-4 gap-y-1">
        {headline}
        {question && (
          <p className="hidden min-w-0 flex-1 truncate text-sm text-ink-3 sm:block" title={question}>
            “{question}”
          </p>
        )}
      </div>
    </div>
  );
}
