"use client";

import type { BriefSection, EvidenceItem, ResearchBrief, ResearchClaim } from "@/lib/api/types";
import { humanize } from "@/lib/format";
import {
  categoryLabel,
  modelName,
  naturalize,
  niceDate,
  niceProviderTime,
  niceRange,
  niceTimestamp,
  timeAgo,
  withoutIds,
} from "@/lib/natural";

import { Card, ClaimTypeBadge, cn, ModeBadge, Notice, StatusBadge } from "../ui";
import { ClaimList, EvidenceChip, evidenceLabel } from "./claims";
import { type ChartBar, type ChartMarker, PriceChart } from "./price-chart";

type Select = (id: string, trigger: HTMLElement) => void;

function bySection(claims: ResearchClaim[], section: BriefSection): ResearchClaim[] {
  return claims.filter((c) => c.section === section);
}

type SectionKind = "market" | "fundamentals" | "filings" | "news";
const SECTION_KINDS: Record<SectionKind, string[]> = {
  market: ["quote", "price_series"],
  fundamentals: ["financial_metric"],
  filings: ["filing"],
  news: ["news"],
};

function sectionEvidence(kind: SectionKind, evidence: Map<string, EvidenceItem>): EvidenceItem[] {
  return [...evidence.values()].filter((e) => SECTION_KINDS[kind].includes(e.kind));
}

/** "Last 3 months (default — not user-selected)" → "Last 3 months". */
function windowName(label: string): string {
  return label.replace(/\s*\(.*\)\s*$/, "");
}

function analysisLabel(brief: ResearchBrief): string {
  if (brief.llm_mode === "fixture") return "Scripted demo analysis (no AI model)";
  const model = modelName(brief.review.reviewer);
  return model ? `AI analysis by ${model}` : "AI analysis";
}

/** One chip per data category: what date the data describes, and whether it is fresh. */
function Freshness({ brief, evidence }: { brief: ResearchBrief; evidence: Map<string, EvidenceItem> }) {
  const a = brief.as_of;
  const chips: { label: string; value: string; kind: SectionKind | null }[] = [
    { label: "Prices", value: a.price_series_end || a.market_observation_date ? niceDate(a.price_series_end ?? a.market_observation_date) : "not available", kind: "market" },
    { label: "Financials", value: a.latest_fiscal_period_end ? `period ended ${niceDate(a.latest_fiscal_period_end)}` : "not available", kind: "fundamentals" },
    { label: "Filings", value: a.latest_filing_date ? niceDate(a.latest_filing_date) : "not available", kind: "filings" },
    { label: "News", value: a.latest_news_published_at ? niceDate(a.latest_news_published_at.slice(0, 10)) : "none available", kind: "news" },
  ];
  return (
    <ul className="flex flex-wrap gap-2" aria-label="Data freshness">
      {chips.map((chip) => {
        const items = chip.kind ? sectionEvidence(chip.kind, evidence) : [];
        const stale = items.some((e) => e.freshness?.status === "stale");
        const missing = chip.value.startsWith("not") || chip.value.startsWith("none");
        return (
          <li
            key={chip.label}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs",
              missing ? "border-dashed border-baseline text-ink-3" : "border-line bg-raised text-ink-2",
            )}
          >
            <span className="font-semibold text-ink">{chip.label}</span>
            <span>{chip.value}</span>
            {stale && <span className="font-semibold text-warning-text">· out of date</span>}
          </li>
        );
      })}
      <li className="inline-flex items-center gap-1.5 rounded-full border border-line bg-raised px-3 py-1 text-xs text-ink-2" title={niceTimestamp(a.latest_retrieved_at)}>
        <span className="font-semibold text-ink">Fetched</span>
        <span>{timeAgo(a.latest_retrieved_at)}</span>
      </li>
    </ul>
  );
}

/** How much of the draft survived checking against the sources. */
function FactCheck({ brief }: { brief: ResearchBrief }) {
  const r = brief.review;
  const total = Math.max(r.claims_total, 1);
  const numbers = r.numeric_checks_passed + (r.numeric_checks_failed ?? 0);
  const segments = [
    { n: r.supported, label: "verified", bar: "bg-good", dot: "bg-good" },
    { n: r.needs_qualification, label: "read with care", bar: "bg-warning", dot: "bg-warning" },
    { n: r.withheld, label: "set aside", bar: "bg-critical/70", dot: "bg-critical/70" },
  ];
  return (
    <div className="rounded-xl border border-line bg-raised p-3.5" data-testid="fact-check">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="text-sm font-semibold text-ink">
          Fact-check: {r.supported} of {r.claims_total} statement{r.claims_total === 1 ? "" : "s"} verified
        </p>
        <p className="text-xs text-ink-3">
          {numbers > 0 ? `${r.numeric_checks_passed} of ${numbers} numbers matched their source` : "No numbers to check"}
        </p>
      </div>
      <div className="mt-2.5 flex h-2 overflow-hidden rounded-full bg-sunken" aria-hidden="true">
        {segments.map((s) =>
          s.n > 0 ? <span key={s.label} className={cn("h-full first:rounded-l-full last:rounded-r-full", s.bar)} style={{ width: `${(s.n / total) * 100}%` }} /> : null,
        )}
      </div>
      <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-2">
        {segments.map((s) => (
          <li key={s.label} className="inline-flex items-center gap-1.5">
            <span aria-hidden="true" className={cn("h-2 w-2 rounded-full", s.dot)} />
            {s.n} {s.label}
          </li>
        ))}
        {r.withheld > 0 && (
          <li>
            <a href="#withheld" className="font-medium text-accent hover:underline">
              Why some were set aside ↓
            </a>
          </li>
        )}
      </ul>
    </div>
  );
}

function BriefIntro({ brief, evidence }: { brief: ResearchBrief; evidence: Map<string, EvidenceItem> }) {
  const h = brief.time_horizon;
  return (
    <Card>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-3">Research brief</p>
          <h2 id="brief-title" className="mt-1 text-2xl font-semibold tracking-tight text-ink">
            {brief.company.company_name}{" "}
            <span className="font-mono text-lg font-medium text-ink-3">{brief.company.symbol}</span>
          </h2>
          <p className="mt-1 text-sm text-ink-2">
            {windowName(h.label)} · {niceRange(h.start_date, h.end_date)}
            {h.is_default && <span className="ml-2 rounded-full bg-sunken px-2 py-0.5 text-[11px] text-ink-3">default window</span>}
            {brief.company.exchange && <span className="text-ink-3"> · {brief.company.exchange}</span>}
          </p>
          <p className="mt-0.5 text-xs text-ink-3" title={niceTimestamp(brief.generated_at)}>
            {analysisLabel(brief)} · written {timeAgo(brief.generated_at)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <StatusBadge status={brief.report_status} />
          <ModeBadge isFixture={brief.is_fixture} />
        </div>
      </div>
      <div className="mt-4 space-y-3">
        <Freshness brief={brief} evidence={evidence} />
        <FactCheck brief={brief} />
        {brief.fixture_disclosure && (
          <Notice tone="warning" title="Synthetic demo data">
            {brief.fixture_disclosure}
          </Notice>
        )}
      </div>
    </Card>
  );
}

/** Per-section "as of": what the data describes vs when it was fetched, plus freshness. */
function SectionAsOf({ kind, brief, evidence }: { kind: SectionKind; brief: ResearchBrief; evidence: Map<string, EvidenceItem> }) {
  const a = brief.as_of;
  const items = sectionEvidence(kind, evidence);
  if (items.length === 0) return null;
  const retrieved = items.map((e) => e.retrieved_at).sort().at(-1);
  const stale = items.find((e) => e.freshness?.status === "stale");
  const fresh = items.some((e) => e.freshness?.status === "fresh");
  const observed = {
    market: a.price_series_end
      ? `Daily closes through ${niceDate(a.price_series_end)}${a.market_observation_date ? ` · quote for ${niceDate(a.market_observation_date)}` : ""}`
      : `Quote for ${niceDate(a.market_observation_date)}`,
    fundamentals: `Latest reporting period ended ${niceDate(a.latest_fiscal_period_end)}`,
    filings: `Latest filing ${niceDate(a.latest_filing_date)}`,
    news: `Latest story ${niceProviderTime(a.latest_news_published_at, false)}`,
  }[kind];
  return (
    <p className="mb-4 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-ink-3" data-testid={`as-of-${kind}`}>
      <span>
        <span className="font-medium text-ink-2">As of </span>
        {observed} · fetched <span title={niceTimestamp(retrieved)}>{timeAgo(retrieved)}</span>
      </span>
      {stale ? (
        <span className="rounded-full border border-warning/60 bg-warning/10 px-2 py-0.5 text-[11px] text-warning-text" title={stale.freshness?.note}>
          ! out of date
        </span>
      ) : fresh ? (
        <span className="rounded-full border border-good/40 bg-good/10 px-2 py-0.5 text-[11px] text-good-text">✓ current</span>
      ) : null}
    </p>
  );
}

function KeyMetrics({ brief, evidence, selected, onSelect }: { brief: ResearchBrief; evidence: Map<string, EvidenceItem>; selected: string | null; onSelect: Select }) {
  const groups: ["market" | "fundamentals", string][] = [
    ["market", "Market"],
    ["fundamentals", "Financial results"],
  ];
  return (
    <div className="space-y-5">
      {groups.map(([group, label]) => {
        const rows = (brief.key_metrics ?? []).filter((m) => m.group === group);
        if (rows.length === 0) return null;
        return (
          <div key={group}>
            <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-ink-3">{label}</h3>
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {rows.map((m) => {
                const signed = /^[+−-]/.test(m.display_value);
                const up = m.display_value.startsWith("+");
                return (
                  <li key={m.label} className="rounded-xl border border-line bg-raised p-3.5">
                    <p className="text-xs text-ink-3">{m.label}</p>
                    <p className={cn("mt-1 text-2xl font-semibold tracking-tight tabular", signed && (up ? "text-good-text" : "text-critical-text"))}>
                      {signed && <span aria-hidden="true" className="mr-1 text-base">{up ? "▲" : "▼"}</span>}
                      {m.display_value}
                    </p>
                    <p className="text-xs text-ink-3">{naturalize(m.as_of)}</p>
                    <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                      <ClaimTypeBadge type={m.claim_type} />
                      {(m.evidence_ids ?? []).slice(0, 2).map((id) => (
                        <EvidenceChip key={id} id={id} evidence={evidence} selected={selected === id} onSelect={onSelect} />
                      ))}
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}
    </div>
  );
}

function chartData(brief: ResearchBrief, evidence: Map<string, EvidenceItem>): { bars: ChartBar[]; markers: ChartMarker[]; subtitle: string } | null {
  const series = [...evidence.values()].find((e) => e.kind === "price_series");
  if (!series) return null;
  const payload = (series.payload ?? {}) as Record<string, unknown>;
  const bars = ((payload.bars as ChartBar[] | undefined) ?? []).map((b) => ({
    ...b,
    open: Number(b.open),
    high: Number(b.high),
    low: Number(b.low),
    close: Number(b.close),
  }));
  const markers: ChartMarker[] = [];
  for (const e of evidence.values()) {
    if (e.kind !== "calculation") continue;
    const p = (e.payload ?? {}) as Record<string, unknown>;
    if (typeof p.trading_date === "string" && p.percentage_change !== undefined && p.category === "market") {
      const pct = Number(p.percentage_change);
      markers.push({ date: p.trading_date, pct, kind: pct < 0 ? "decline" : "gain" });
    }
  }
  const subtitle = [
    `Trading days ${niceRange(String(payload.first_date), String(payload.last_date))}`,
    String(payload.adjustment ?? "unknown adjustment"),
    brief.is_fixture ? "synthetic demo data" : series.source_name,
  ].join(" · ");
  return { bars, markers, subtitle };
}

const WITHHELD_REASON: Record<string, string> = {
  numeric_mismatch: "Numbers didn't match the sources",
  date_mismatch: "Dates weren't in the sources",
  unsupported: "Not backed by a retrieved source",
  contradicted: "Contradicted by the sources",
  unverified: "Couldn't be verified",
  needs_qualification: "Needed qualification",
};

function Gaps({ brief, hiddenCodes }: { brief: ResearchBrief; hiddenCodes: string[] }) {
  const gaps = (brief.unknowns_and_gaps ?? []).filter((g) => !g.reason_code || !hiddenCodes.includes(g.reason_code));
  const notes = gaps.filter((g) => g.reason_code === "AGENT_NOTE");
  const main = gaps.filter((g) => g.reason_code !== "AGENT_NOTE");
  const quality = brief.source_quality_notes ?? [];
  if (main.length === 0 && notes.length === 0 && quality.length === 0) return null;
  return (
    <Card title="What this brief couldn't establish" description="Stated plainly instead of guessed.">
      {main.length > 0 && (
        <ul className="grid gap-2.5 sm:grid-cols-2">
          {main.map((gap, i) => {
            const material = gap.severity === "material";
            return (
              <li key={i} className={cn("flex gap-3 rounded-xl border p-3 text-sm", material ? "border-warning/50 bg-warning/[0.07]" : "border-line bg-raised")}>
                <span
                  aria-hidden="true"
                  className={cn(
                    "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-[11px] font-bold",
                    material ? "bg-warning/30 text-warning-text" : "bg-sunken text-ink-3",
                  )}
                >
                  {material ? "!" : "i"}
                </span>
                <span className="text-ink-2">
                  <span className="sr-only">{material ? "Important: " : "Note: "}</span>
                  {gap.category && <span className="font-medium text-ink">{categoryLabel(gap.category)}: </span>}
                  {naturalize(gap.description)}
                </span>
              </li>
            );
          })}
        </ul>
      )}
      {quality.length > 0 && (
        <div className="mt-4">
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-ink-3">About the sources</h3>
          <ul className="mt-1.5 space-y-1 text-sm text-ink-2">
            {quality.map((n) => (
              <li key={n}>{naturalize(n)}</li>
            ))}
          </ul>
        </div>
      )}
      {notes.length > 0 && (
        <details className="group mt-4 rounded-xl border border-line bg-raised px-3.5 py-2.5">
          <summary className="cursor-pointer text-sm font-medium text-ink-2 hover:text-ink">Notes from the AI analysts ({notes.length})</summary>
          <ul className="mt-2 space-y-1.5 text-sm text-ink-2">
            {notes.map((n, i) => (
              <li key={i}>{naturalize(n.description)}</li>
            ))}
          </ul>
        </details>
      )}
    </Card>
  );
}

function SetAside({ brief }: { brief: ResearchBrief }) {
  const withheld = brief.withheld_claims ?? [];
  if (withheld.length === 0) return null;
  return (
    <Card
      id="withheld"
      title={`Set aside by the fact-checker (${withheld.length})`}
      description="Draft statements that failed checks against the sources. They are not part of the findings."
    >
      <details className="rounded-xl border border-line bg-raised px-3.5 py-2.5">
        <summary className="cursor-pointer text-sm font-medium text-ink-2 hover:text-ink">Show what was set aside and why</summary>
        <ul className="mt-3 space-y-2.5">
          {withheld.map((c) => (
            <li key={c.claim_id} className="rounded-lg border border-line bg-surface p-3 text-sm">
              <span className="inline-flex rounded-full border border-critical/30 bg-critical/10 px-2 py-0.5 text-[11px] font-medium text-critical-text">
                {WITHHELD_REASON[c.validation_status] ?? humanize(c.validation_status)}
              </span>
              <p className="mt-1.5 italic leading-relaxed text-ink-3">“{naturalize(c.text)}”</p>
              {(c.validation_notes ?? []).length > 0 && <p className="mt-1 text-xs text-ink-2">{withoutIds((c.validation_notes ?? []).join(" "))}</p>}
            </li>
          ))}
        </ul>
      </details>
    </Card>
  );
}

function Sources({ brief, evidence, selected, onSelect }: { brief: ResearchBrief; evidence: Map<string, EvidenceItem>; selected: string | null; onSelect: Select }) {
  const sources = brief.sources ?? [];
  return (
    <details className="rounded-2xl border border-line bg-surface p-5">
      <summary className="cursor-pointer font-semibold tracking-tight text-ink">
        Sources <span className="font-normal text-ink-3">({sources.length})</span>
      </summary>
      <p className="mt-1 text-sm text-ink-3">Every item retrieved or calculated for this brief. Select one to inspect it.</p>
      <ul className="mt-3 divide-y divide-hairline">
        {sources.map((s) => {
          const item = evidence.get(s.evidence_id);
          const when = s.published_at
            ? niceProviderTime(s.published_at, item?.published_at_tz_known)
            : s.period_end
              ? niceRange(s.period_start, s.period_end)
              : null;
          return (
            <li key={s.evidence_id} className="flex flex-wrap items-start gap-x-3 gap-y-1 py-2.5 text-sm">
              <EvidenceChip id={s.evidence_id} evidence={evidence} selected={selected === s.evidence_id} onSelect={onSelect} />
              <span className="min-w-0 flex-1">
                <span className="block text-ink">{naturalize(s.title) || evidenceLabel(item, s.evidence_id)}</span>
                <span className="block text-xs text-ink-3">
                  {s.source_name}
                  {when ? ` · ${when}` : ""} · fetched {timeAgo(s.retrieved_at)}
                </span>
              </span>
            </li>
          );
        })}
      </ul>
    </details>
  );
}

function Method({ brief }: { brief: ResearchBrief }) {
  return (
    <details className="rounded-2xl border border-line bg-surface p-5">
      <summary className="cursor-pointer font-semibold tracking-tight text-ink">How this analysis was prepared</summary>
      <ol className="mt-4 space-y-2.5 text-sm">
        {brief.methodology.steps.map((step, i) => (
          <li key={step.name} className="flex gap-3">
            <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-sunken text-[11px] font-semibold text-ink-2">{i + 1}</span>
            <span>
              <span className="font-medium text-ink">{step.name}</span> <span className="text-xs text-ink-3">({humanize(step.agent)})</span>
              <span className="block text-ink-2">{step.description}</span>
            </span>
          </li>
        ))}
      </ol>
      <div className="mt-5 grid gap-4 text-sm md:grid-cols-2">
        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-ink-3">Calculated by code, not the AI</h3>
          <ul className="mt-1.5 list-disc space-y-0.5 pl-5 text-ink-2">
            {brief.methodology.deterministic_calculations.map((c) => (
              <li key={c}>{c}</li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-ink-3">Written by the AI</h3>
          <p className="mt-1.5 text-ink-2">
            {brief.methodology.model_generated.length === 0
              ? "Nothing: this brief was composed from retrieved values without a language model."
              : brief.methodology.model_generated.join("; ")}
          </p>
          <h3 className="mt-4 text-[11px] font-semibold uppercase tracking-wider text-ink-3">Limitations</h3>
          <ul className="mt-1.5 list-disc space-y-0.5 pl-5 text-ink-2">
            {(brief.limitations ?? []).map((l) => (
              <li key={l}>{l}</li>
            ))}
          </ul>
        </div>
      </div>
    </details>
  );
}

export function BriefView({
  brief,
  evidence,
  selectedEvidence,
  onSelectEvidence,
  hiddenGapCodes = [],
}: {
  brief: ResearchBrief;
  evidence: Map<string, EvidenceItem>;
  selectedEvidence: string | null;
  onSelectEvidence: Select;
  /** Gap reasons already explained in the run's "Heads up" card. */
  hiddenGapCodes?: string[];
}) {
  const claims = brief.claims ?? [];
  const common = { evidence, selectedEvidence, onSelectEvidence };
  const chart = chartData(brief, evidence);
  const scenarios = bySection(claims, "scenarios");

  return (
    <article className="space-y-6" aria-labelledby="brief-title">
      <BriefIntro brief={brief} evidence={evidence} />

      <Card title="Summary" description="A balanced overview. Not a recommendation to buy or sell.">
        <ClaimList claims={bySection(claims, "executive_summary")} {...common} empty="No summary statements passed the fact-check for this run." />
      </Card>

      <Card title="Key numbers" description="Each value shows the period it describes; select a source to see where it came from.">
        <KeyMetrics brief={brief} evidence={evidence} selected={selectedEvidence} onSelect={onSelectEvidence} />
      </Card>

      <Card title="Price movement">
        <SectionAsOf kind="market" brief={brief} evidence={evidence} />
        {chart && chart.bars.length > 0 && (
          <div className="mb-4">
            <PriceChart symbol={brief.company.symbol} bars={chart.bars} markers={chart.markers} subtitle={chart.subtitle} />
          </div>
        )}
        <ClaimList claims={bySection(claims, "market_movement")} {...common} empty="Price history wasn't available for this run." />
      </Card>

      <Card title="Financial results" description="Reported values with units, currency and reporting period.">
        <SectionAsOf kind="fundamentals" brief={brief} evidence={evidence} />
        <ClaimList claims={bySection(claims, "fundamentals")} {...common} empty="Financial results weren't available for this run." />
      </Card>

      <Card title="SEC filings">
        <SectionAsOf kind="filings" brief={brief} evidence={evidence} />
        <ClaimList claims={bySection(claims, "filings")} {...common} empty="Filing details weren't available for this run." />
      </Card>

      <Card title="News and events" description="Dated context only: a story published near a price move doesn't prove it caused it.">
        <SectionAsOf kind="news" brief={brief} evidence={evidence} />
        {(brief.recent_events ?? []).length === 0 ? (
          <p className="text-sm text-ink-3">No news stories from this period are available for this run.</p>
        ) : (
          <ol className="relative space-y-4 border-l-2 border-hairline pl-5">
            {(brief.recent_events ?? []).map((event) => (
              <li key={event.evidence_id} className="relative">
                <span aria-hidden="true" className="absolute -left-[1.6rem] top-1.5 h-2.5 w-2.5 rounded-full border-2 border-surface bg-[#eda100]" />
                <p className="text-xs font-medium text-ink-3">{niceProviderTime(event.published_at, event.published_at_tz_known)}</p>
                <p className="mt-0.5 font-medium leading-snug text-ink">{event.headline}</p>
                <p className="mt-0.5 text-sm text-ink-2">{naturalize(event.relevance_note)}</p>
                <p className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-ink-3">
                  <span>{event.publisher ?? "Unknown publisher"}</span>
                  <EvidenceChip id={event.evidence_id} evidence={evidence} selected={selectedEvidence === event.evidence_id} onSelect={onSelectEvidence} />
                </p>
              </li>
            ))}
          </ol>
        )}
        {bySection(claims, "recent_events").length > 0 && (
          <div className="mt-4 border-t border-hairline pt-2">
            <ClaimList claims={bySection(claims, "recent_events")} {...common} />
          </div>
        )}
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card title="What looks positive">
          <ClaimList claims={bySection(claims, "positive_evidence")} {...common} empty="Nothing positive stood out in the evidence." />
        </Card>
        <Card title="What looks negative">
          <ClaimList claims={bySection(claims, "negative_evidence")} {...common} empty="Nothing negative stood out in the evidence." />
        </Card>
      </div>

      <Card title="Risks" description="Quoted from filings or drawn from cited evidence.">
        <ClaimList claims={bySection(claims, "risks")} {...common} empty="No risk statements passed the fact-check for this run." />
      </Card>

      <Card title="Interpretation" description="Analysis, not fact. The wording says how certain it is.">
        <ClaimList claims={bySection(claims, "interpretation")} {...common} empty="No interpretations passed the fact-check." />
      </Card>

      {scenarios.length > 0 && (
        <Card title="Scenarios" description="Conditional and qualitative, with stated assumptions. Not forecasts.">
          <ClaimList claims={scenarios} {...common} />
        </Card>
      )}

      <Gaps brief={brief} hiddenCodes={hiddenGapCodes} />
      <SetAside brief={brief} />
      <Sources brief={brief} evidence={evidence} selected={selectedEvidence} onSelect={onSelectEvidence} />
      <Method brief={brief} />

      <p className="rounded-xl border border-line bg-sunken px-4 py-3 text-xs leading-relaxed text-ink-2" data-testid="brief-disclaimer">
        {brief.disclaimer}
      </p>
    </article>
  );
}
