"use client";

import { useEffect, useRef } from "react";

import type { EvidenceItem, ResearchClaim } from "@/lib/api/types";
import { humanize } from "@/lib/format";
import { naturalize, niceProviderTime, niceRange, niceTimestamp } from "@/lib/natural";

import { ModeBadge, Notice } from "../ui";
import { evidenceLabel } from "./claims";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[7.5rem_1fr] gap-2 py-1.5 text-sm">
      <dt className="text-ink-3">{label}</dt>
      <dd className="min-w-0 break-words text-ink">{children}</dd>
    </div>
  );
}

function isFixtureUrl(url: string): boolean {
  return url.startsWith("https://example.com/marketlens-fixture");
}

function ValueTable({ rows }: { rows: [string, unknown][] }) {
  return (
    <table className="w-full text-left text-xs tabular">
      <tbody>
        {rows.map(([key, value]) => (
          <tr key={key} className="border-t border-hairline">
            <th className="w-2/5 py-1 pr-2 font-medium text-ink-3">{humanize(key)}</th>
            <td className="py-1 text-ink">{value === null || value === undefined ? "—" : String(value)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function PayloadView({
  item,
  evidence,
  onSelect,
}: {
  item: EvidenceItem;
  evidence: Map<string, EvidenceItem>;
  onSelect: (id: string, trigger: HTMLElement) => void;
}) {
  const payload = (item.payload ?? {}) as Record<string, unknown>;
  if (item.kind === "calculation") {
    const inputs = (payload.input_evidence_ids as string[] | undefined) ?? [];
    const rows = Object.entries(payload).filter(([k]) => !["formula", "input_evidence_ids", "category"].includes(k));
    return (
      <div className="space-y-3">
        <div>
          <p className="text-xs font-medium text-ink-3">Formula</p>
          <p className="mt-0.5 rounded bg-sunken px-2 py-1 font-mono text-xs">{String(payload.formula ?? "—")}</p>
        </div>
        <div>
          <p className="text-xs font-medium text-ink-3">Inputs</p>
          <ul className="mt-1 flex flex-wrap gap-1.5">
            {inputs.map((id) => (
              <li key={id}>
                <button
                  type="button"
                  onClick={(e) => onSelect(id, e.currentTarget)}
                  className="rounded border border-line bg-raised px-1.5 py-0.5 font-mono text-[11px] text-accent hover:border-accent"
                >
                  {evidenceLabel(evidence.get(id), id)}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <ValueTable rows={rows} />
      </div>
    );
  }
  if (item.kind === "price_series") {
    const bars = (payload.bars as { trading_date: string; close: number }[] | undefined) ?? [];
    return (
      <ValueTable
        rows={[
          ["bar_count", payload.bar_count],
          ["first_date", payload.first_date],
          ["last_date", payload.last_date],
          ["adjustment", payload.adjustment],
          ["timezone", payload.timezone],
          ["first_close", bars[0]?.close],
          ["last_close", bars[bars.length - 1]?.close],
        ]}
      />
    );
  }
  if (item.kind === "financial_metric") {
    const values = (payload.values as Record<string, unknown>[] | undefined) ?? [];
    return (
      <div className="max-h-56 overflow-auto">
        <table className="w-full text-left text-xs tabular">
          <thead className="text-ink-3">
            <tr>
              <th className="py-1 pr-2 font-medium">Period</th>
              <th className="py-1 pr-2 text-right font-medium">Value</th>
              <th className="py-1 font-medium">Filing</th>
            </tr>
          </thead>
          <tbody>
            {values.map((v, i) => (
              <tr key={i} className="border-t border-hairline">
                <td className="py-1 pr-2">
                  {String(v.start ?? "?")} → {String(v.end ?? v.period_end ?? "?")}
                </td>
                <td className="py-1 pr-2 text-right">{String(v.value)}</td>
                <td className="py-1">{[v.form, v.filed].filter(Boolean).map(String).join(" · ") || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-1 text-[11px] text-ink-3">
          Units: {item.units ?? "—"} {payload.concept ? `· us-gaap:${String(payload.concept)}` : ""}
        </p>
      </div>
    );
  }
  const rows = Object.entries(payload).filter(([, v]) => typeof v !== "object" || v === null);
  return rows.length ? <ValueTable rows={rows} /> : null;
}

export function EvidenceInspector({
  item,
  evidence,
  claims,
  onSelect,
  onClose,
}: {
  item: EvidenceItem;
  evidence: Map<string, EvidenceItem>;
  claims: ResearchClaim[];
  onSelect: (id: string, trigger: HTMLElement) => void;
  onClose: () => void;
}) {
  const headingRef = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    headingRef.current?.focus();
  }, [item.evidence_id]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const citedBy = claims.filter((c) => (c.evidence_ids ?? []).includes(item.evidence_id));
  const injection = item.flags?.includes("suspected_prompt_injection");

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-start justify-between gap-3 border-b border-line px-5 py-4">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-3">Source · {evidenceLabel(item, item.evidence_id)}</p>
          <h2 ref={headingRef} tabIndex={-1} className="mt-1 text-base font-semibold leading-snug text-ink outline-none">
            {naturalize(item.title) || "Evidence item"}
          </h2>
          <div className="mt-2">
            <ModeBadge isFixture={item.is_fixture} />
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-md px-2 py-1 text-sm text-ink-2 hover:bg-sunken"
          aria-label="Close evidence inspector"
        >
          ✕
        </button>
      </div>
      <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
        {injection && (
          <Notice tone="warning" title="Untrusted content flagged">
            This source contains instruction-like text. MarketLens treats it as data only: it is excluded from the
            analysis and nothing in it was followed.
          </Notice>
        )}
        <dl className="divide-y divide-hairline">
          <Field label="Source">{item.source_name}</Field>
          <Field label="Provider">{humanize(item.provider)}</Field>
          <Field label="Link">
            {item.source_url ? (
              <>
                <a href={item.source_url} target="_blank" rel="noopener noreferrer nofollow" className="text-accent underline-offset-2 hover:underline">
                  {item.source_url}
                </a>
                {isFixtureUrl(item.source_url) && (
                  <span className="mt-0.5 block text-xs text-ink-3">Synthetic placeholder URL on a documentation domain — not a real document.</span>
                )}
              </>
            ) : (
              <span className="text-ink-3">Not applicable / not provided</span>
            )}
          </Field>
          <Field label="Published">{niceProviderTime(item.published_at ?? item.published_date, item.published_at_tz_known)}</Field>
          <Field label="Period">{item.period_start || item.period_end ? niceRange(item.period_start, item.period_end) : "—"}</Field>
          <Field label="Fetched">{niceTimestamp(item.retrieved_at)}</Field>
          <Field label="Units">{[item.currency, item.units].filter(Boolean).join(" · ") || "—"}</Field>
          {item.freshness && (
            <Field label="Freshness">
              <span className={item.freshness.status === "stale" ? "font-semibold text-warning-text" : undefined}>
                {item.freshness.status === "stale" ? "! Stale" : item.freshness.status === "fresh" ? "✓ Fresh" : "? Unknown"}
              </span>{" "}
              <span className="text-ink-3">— {naturalize(item.freshness.note)}</span>
            </Field>
          )}
          {item.flags && item.flags.length > 0 && <Field label="Flags">{item.flags.map(humanize).join(", ")}</Field>}
        </dl>

        {item.excerpt && (
          <div>
            <p className="text-xs font-medium text-ink-3">Excerpt (untrusted source text, quoted not followed)</p>
            <blockquote className="mt-1 whitespace-pre-line border-l-2 border-baseline pl-3 text-sm text-ink-2">{item.excerpt}</blockquote>
          </div>
        )}

        <div>
          <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink-3">Exact values from the source</p>
          <PayloadView item={item} evidence={evidence} onSelect={onSelect} />
        </div>

        {item.notes && item.notes.length > 0 && (
          <ul className="list-disc space-y-0.5 pl-5 text-xs text-ink-3">
            {item.notes.map((n) => (
              <li key={n}>{n}</li>
            ))}
          </ul>
        )}

        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-3">Cited by {citedBy.length} claim(s)</p>
          <ul className="mt-1 space-y-1.5">
            {citedBy.map((c) => (
              <li key={c.claim_id} className="rounded-md bg-sunken px-2.5 py-1.5 text-xs text-ink-2">
                <a href={`#${c.claim_id}`} className="hover:underline">
                  {c.text}
                </a>
              </li>
            ))}
            {citedBy.length === 0 && <li className="text-xs text-ink-3">Used as an input to calculations or listed as a source.</li>}
          </ul>
        </div>

        <p className="break-all font-mono text-[11px] text-ink-3">
          {item.evidence_id} · {item.content_hash}
        </p>
      </div>
    </div>
  );
}
