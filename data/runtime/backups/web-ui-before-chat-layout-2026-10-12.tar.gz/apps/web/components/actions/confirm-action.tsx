"use client";

import { useCallback, useEffect, useId, useRef, useState } from "react";

import { api, ApiError } from "@/lib/api/client";
import type { ConfirmActionResponse, PendingAction, PendingActionResponse } from "@/lib/api/types";
import { formatTimestamp } from "@/lib/format";
import { naturalize } from "@/lib/natural";

import { Overlay } from "../modal";
import { buttonClass, ModeBadge, Notice } from "../ui";

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

const COPY: Record<PendingAction["action_type"], { title: (a: PendingAction) => string; verb: string }> = {
  save_research_brief: { title: () => "Save this research brief?", verb: "Save brief" },
  add_watchlist_symbol: { title: (a) => `Add ${a.symbol} to your watchlist?`, verb: "Add to watchlist" },
  remove_watchlist_symbol: { title: (a) => `Remove ${a.symbol} from your watchlist?`, verb: "Remove" },
};

/**
 * Explicit confirmation for a server-proposed write. The browser never sees or sends a
 * grant: confirming asks the backend (over the HTTP-only session) to issue a one-time grant
 * and perform the MCP write; the server re-validates everything.
 */
export function ConfirmActionDialog({
  action,
  onDone,
  onClose,
}: {
  action: PendingAction;
  onDone: (result: ConfirmActionResponse) => void;
  onClose: () => void;
}) {
  const titleId = useId();
  const descId = useId();
  const cancelRef = useRef<HTMLButtonElement>(null);
  const confirmRef = useRef<HTMLButtonElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const copy = COPY[action.action_type];
  const destructive = action.action_type === "remove_watchlist_symbol";
  const summary = (action.summary ?? {}) as Record<string, unknown>;

  const cancel = useCallback(async () => {
    if (busy) return;
    try {
      await api<PendingActionResponse>(`/api/actions/${action.action_id}/cancel`, { method: "POST" });
    } catch {
      // Best effort: an unconfirmed proposal also expires on its own.
    }
    onClose();
  }, [action.action_id, busy, onClose]);

  useEffect(() => {
    (destructive ? cancelRef : confirmRef).current?.focus();
  }, [destructive]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") void cancel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [cancel]);

  async function confirm() {
    setBusy(true);
    setError(null);
    try {
      const result = await api<ConfirmActionResponse>(`/api/actions/${action.action_id}/confirm`, { method: "POST" });
      onDone(result);
    } catch (err) {
      setError(err instanceof ApiError ? err : new ApiError("UNKNOWN", "The change was not saved.", 0));
      setBusy(false);
    }
  }

  const rows: [string, React.ReactNode][] = [
    ["Action", copy.verb],
    ...(action.symbol ? ([["Symbol", <span key="s" className="font-mono">{action.symbol}</span>]] as [string, React.ReactNode][]) : []),
    ...(summary.display_name ? ([["Company", String(summary.display_name)]] as [string, React.ReactNode][]) : []),
    ...(action.title ? ([["Title", naturalize(action.title)]] as [string, React.ReactNode][]) : []),
    ["Destination", `${capitalize(String(summary.destination ?? "workspace"))} (local database on this machine)`],
    ...(summary.data_mode
      ? ([["Data", <ModeBadge key="m" isFixture={summary.data_mode === "fixture"} />]] as [string, React.ReactNode][])
      : []),
    ["Expires", formatTimestamp(action.expires_at)],
  ];

  // Portalled to the body: a sticky or blurred ancestor (the run bar) would trap a fixed overlay.
  return (
    <Overlay>
      <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4" data-confirm-dialog onClick={() => void cancel()}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descId}
        className="w-full max-w-md rounded-2xl border border-line bg-surface p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id={titleId} className="text-lg font-semibold">
          {copy.title(action)}
        </h2>
        <p id={descId} className="mt-1 text-sm text-ink-2">
          Nothing changes until you confirm. This only writes to MarketLens&apos;s local workspace — it never trades or
          contacts a brokerage.
        </p>
        <dl className="mt-4 divide-y divide-hairline rounded-lg border border-line bg-raised px-3">
          {rows.map(([label, value]) => (
            <div key={label} className="grid grid-cols-[6.5rem_1fr] gap-2 py-2 text-sm">
              <dt className="text-ink-3">{label}</dt>
              <dd className="min-w-0 break-words">{value}</dd>
            </div>
          ))}
        </dl>
        {error && (
          <div className="mt-4">
            <Notice tone="critical" title="Not saved">
              {error.message}
              {error.code === "CONFIRMATION_EXPIRED" && " Close this dialog and try again."}
            </Notice>
          </div>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <button ref={cancelRef} type="button" className={buttonClass.secondary} onClick={() => void cancel()} disabled={busy}>
            Cancel
          </button>
          <button ref={confirmRef} type="button" className={buttonClass.primary} onClick={() => void confirm()} disabled={busy}>
            {busy ? "Working…" : `Confirm: ${copy.verb.toLowerCase()}`}
          </button>
        </div>
      </div>
    </div>
    </Overlay>
  );
}

/** Propose a write, then show the confirmation dialog for the server-issued pending action. */
export function useProposal() {
  const [pending, setPending] = useState<PendingAction | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [proposing, setProposing] = useState(false);

  const propose = useCallback(async (path: string, init: RequestInit & { json?: unknown }) => {
    setProposing(true);
    setError(null);
    try {
      const response = await api<PendingActionResponse>(path, init);
      setPending(response.action);
    } catch (err) {
      setError(err instanceof ApiError ? err : new ApiError("UNKNOWN", "The request failed.", 0));
    } finally {
      setProposing(false);
    }
  }, []);

  return { pending, setPending, error, setError, proposing, propose };
}
