"use client";

import type { AnalyticsSummary, DataStatus } from "@/lib/api/types";
import { formatTimestamp, humanize } from "@/lib/format";
import { useApi } from "@/lib/use-api";

import { useStatus } from "../status-provider";
import { Card, cn, ModeBadge, Notice, Spinner } from "../ui";

const CAPABILITY_LABELS: Record<string, string> = {
  fixture_data: "Fixture data",
  live_market_data: "Live market data",
  live_sec_data: "Live SEC data",
  live_news: "Live news",
  live_llm: "Live LLM",
  voice: "Voice",
  transcript_persistence: "Transcript persistence",
};

function YesNo({ value }: { value: boolean | null | undefined }) {
  if (value === null || value === undefined) {
    return <span className="text-xs font-semibold text-ink-3">? Unknown until first use</span>;
  }
  return value ? (
    <span className="text-xs font-semibold text-good-text">✓ Yes</span>
  ) : (
    <span className="text-xs font-semibold text-ink-3">– No</span>
  );
}

export function DataStatusView() {
  const { health, error: healthError } = useStatus();
  const { data, error, loading, reload } = useApi<DataStatus>("/api/data-status");

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink-2">Shows whether settings are present, never the secret values themselves.</p>
        <button type="button" onClick={reload} className="rounded-lg border border-line bg-raised px-3 py-1.5 text-sm hover:bg-sunken">
          Refresh
        </button>
      </div>

      {healthError && <Notice tone="critical">{healthError.message}</Notice>}

      {health && (
        <Card title="Modes" actions={<ModeBadge isFixture={health.data_mode === "fixtures"} />}>
          <dl className="grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["App mode", health.app_mode === "demo" ? "Demo (works offline)" : "Live"],
              ["Data", health.data_mode === "fixtures" ? "Synthetic demo fixtures" : "Live providers"],
              ["Analysis", health.llm_mode === "fixture" ? "Scripted demo (no AI model)" : "AI model (OpenAI-compatible API)"],
              [
                "Voice",
                health.voice_enabled
                  ? "enabled (LiveKit)"
                  : health.voice_mode === "disabled"
                    ? "disabled"
                    : `not configured (${health.voice_mode} selected, credentials missing)`,
              ],
              ["Tool transport", health.tool_transport === "mcp_stdio" ? "MCP over stdio" : "in-process (temporary)"],
              ["Backend version", health.version],
            ].map(([label, value]) => (
              <div key={label}>
                <dt className="text-xs text-ink-3">{label}</dt>
                <dd className="font-medium">{value}</dd>
              </div>
            ))}
          </dl>
          <h3 className="mt-5 text-xs font-semibold uppercase tracking-wide text-ink-3">Configured capabilities</h3>
          <ul className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {Object.entries(health.capabilities).map(([name, value]) => (
              <li key={name} className="flex items-center justify-between rounded-md border border-line bg-raised px-3 py-1.5 text-sm">
                <span>{CAPABILITY_LABELS[name] ?? humanize(name)}</span>
                <YesNo value={value} />
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-ink-3">{health.research_only_notice}</p>
        </Card>
      )}

      {health && Object.keys(health.mcp_servers ?? {}).length > 0 && (
        <Card title="MCP servers" description="Each server runs as its own process; the backend reaches it only over MCP (stdio).">
          <ul className="grid gap-3 md:grid-cols-3">
            {Object.entries(health.mcp_servers ?? {}).map(([id, server]) => (
              <li key={id} className="rounded-lg border border-line bg-raised p-3 text-sm">
                <p className="flex items-center justify-between">
                  <span className="font-mono font-medium">{id}</span>
                  <span className={server.ready ? "text-xs font-semibold text-good-text" : "text-xs font-semibold text-critical-text"}>
                    {server.ready ? "✓ Ready" : "✕ Unavailable"}
                  </span>
                </p>
                <p className="mt-1 text-xs text-ink-3">
                  {server.tools.length} tools · {server.restarts} restart{server.restarts === 1 ? "" : "s"}
                </p>
                <p className="mt-1 font-mono text-[11px] leading-relaxed text-ink-2">{server.tools.join(" · ")}</p>
                {server.last_error && <p className="mt-1 text-xs text-critical-text">{server.last_error}</p>}
              </li>
            ))}
          </ul>
        </Card>
      )}

      {loading && <Spinner label="Checking data sources…" />}
      {error && <Notice tone="warning">{error.message}</Notice>}
      {data && (
        <>
          {data.notices.length > 0 && (
            <Notice tone="warning" title="Data disclosure">
              <ul className="list-disc pl-4">
                {data.notices.map((n) => (
                  <li key={n}>{n}</li>
                ))}
              </ul>
            </Notice>
          )}
          <Card title="Reference clock" description="The date used for default research windows and freshness labels.">
            <p className="text-sm">
              <span className="font-medium">{data.reference_basis ?? "unknown"}</span>
              {data.reference_time && <span className="text-ink-3"> · {formatTimestamp(data.reference_time)}</span>}
            </p>
            {data.fixture_dataset_version && (
              <p className="mt-1 text-sm text-ink-2">Fixture dataset: {data.fixture_dataset_version}</p>
            )}
          </Card>
          {data.servers.map((server) => (
            <Card key={server.server} title={`MCP server: ${server.server}`} description={`Data mode ${server.data_mode}`}>
              <div className="space-y-4">
                {server.sources.map((source) => (
                  <div key={source.provider} className="rounded-lg border border-line bg-raised p-3">
                    <p className="flex flex-wrap items-center justify-between gap-2 text-sm">
                      <span className="font-medium">{humanize(source.provider)}</span>
                      <span className="text-xs text-ink-3">
                        Configured: <YesNo value={source.configured} /> · last success{" "}
                        {source.last_successful_retrieval ? formatTimestamp(source.last_successful_retrieval) : "none yet"}
                        {source.rate_limited ? ` · rate limited (retry in ${source.retry_after_seconds}s)` : ""}
                      </span>
                    </p>
                    <ul className="mt-2 grid gap-1.5 sm:grid-cols-2">
                      {source.capabilities.map((cap) => (
                        <li key={cap.name} className="flex items-start justify-between gap-2 text-sm">
                          <span>
                            {humanize(cap.name)}
                            {cap.note && <span className="block text-xs text-ink-3">{cap.note}</span>}
                          </span>
                          <YesNo value={cap.available} />
                        </li>
                      ))}
                    </ul>
                    {(source.limitations ?? []).length > 0 && (
                      <ul className="mt-2 list-disc space-y-0.5 pl-5 text-xs text-ink-3">
                        {(source.limitations ?? []).map((l) => (
                          <li key={l}>{l}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          ))}
          {data.unavailable_servers.length > 0 && (
            <Notice tone="critical" title="Servers not responding">
              {data.unavailable_servers.join(", ")}
            </Notice>
          )}
          <Card title="Latest research by symbol">
            {Object.keys(data.latest_research_by_symbol).length === 0 ? (
              <p className="text-sm text-ink-3">No completed research yet.</p>
            ) : (
              <ul className="grid gap-2 sm:grid-cols-3">
                {Object.entries(data.latest_research_by_symbol).map(([symbol, at]) => (
                  <li key={symbol} className={cn("rounded-md border border-line bg-raised px-3 py-2 text-sm")}>
                    <span className="font-mono font-semibold">{symbol}</span>
                    <span className="block text-xs text-ink-3">{formatTimestamp(at)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </>
      )}
      <UsageCard />
    </div>
  );
}

function rate(value: number | null | undefined): string {
  return value === null || value === undefined ? "—" : `${(value * 100).toFixed(0)}%`;
}

function seconds(ms: number | null | undefined): string {
  return ms === null || ms === undefined ? "—" : `${(ms / 1000).toFixed(1)} s`;
}

/** Local product analytics (FR-23): counts and rates only, stored in the local database. */
function UsageCard() {
  const { data, error, loading } = useApi<AnalyticsSummary>("/api/analytics/summary");
  return (
    <Card
      title="Local usage analytics"
      description="Counts and rates kept in this machine's database only: no personal data, tickers, free text, secrets, transcripts or audio."
    >
      {loading && <Spinner label="Loading usage…" />}
      {error && <Notice tone="warning">{error.message}</Notice>}
      {data && (
        <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2 lg:grid-cols-4">
          {(
            [
              ["Research runs started", String(data.runs.started)],
              ["Completed / partial", `${rate(data.runs.completion_rate)} / ${rate(data.runs.partial_rate)}`],
              ["Median / p95 duration", `${seconds(data.runs.median_duration_ms)} / ${seconds(data.runs.p95_duration_ms)}`],
              ["Briefs saved", String(data.workspace.briefs_saved)],
              ["Watchlist changes", String(Object.values(data.workspace.watchlist_changes).reduce((a, b) => a + b, 0))],
              ["Period comparisons", String(data.periods_compared)],
              ["Voice sessions", String(data.voice.sessions_created)],
              ["Voice connections ok / failed", `${data.voice.connections_succeeded} / ${data.voice.connections_failed}`],
            ] as const
          ).map(([label, value]) => (
            <div key={label}>
              <dt className="text-xs text-ink-3">{label}</dt>
              <dd className="font-medium tabular text-ink">{value}</dd>
            </div>
          ))}
        </dl>
      )}
      {data && Object.keys(data.categories).length > 0 && (
        <div className="mt-4">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-ink-3">Source categories across finished runs</h3>
          <ul className="mt-2 grid gap-2 sm:grid-cols-4">
            {Object.entries(data.categories).map(([category, outcomes]) => (
              <li key={category} className="rounded-md border border-line bg-raised px-3 py-2 text-xs">
                <span className="font-medium capitalize text-ink">{category}</span>
                <span className="block text-ink-3">
                  {Object.entries(outcomes)
                    .map(([status, n]) => `${humanize(status)} ${n}`)
                    .join(" · ")}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Card>
  );
}
