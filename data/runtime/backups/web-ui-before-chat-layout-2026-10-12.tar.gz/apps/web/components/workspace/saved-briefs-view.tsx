"use client";

import type { BriefListResponse } from "@/lib/api/types";
import { naturalize, niceTimestamp, timeAgo } from "@/lib/natural";
import { useApi } from "@/lib/use-api";

import { EmptyState, ModeBadge, Notice, Spinner, StatusBadge } from "../ui";
import { useWorkspace } from "./workspace-context";

/** Saved snapshots (shown in a dialog); choosing one opens it in the main pane. */
export function SavedBriefsView() {
  const ws = useWorkspace();
  const { data, error, loading } = useApi<BriefListResponse>(`/api/briefs?limit=50&v=${ws.version}`);
  return (
    <div>
      {loading && <Spinner label="Loading saved briefs…" />}
      {error && <Notice tone="warning">{error.message}</Notice>}
      {data && data.briefs.length === 0 && (
        <EmptyState title="No saved briefs yet">Open a finished research brief and choose “Save brief”.</EmptyState>
      )}
      {data && data.briefs.length > 0 && (
        <ul className="space-y-2">
          {data.briefs.map((b) => (
            <li key={b.brief_id}>
              <button
                type="button"
                onClick={() => ws.openSaved(b.brief_id)}
                className="flex w-full flex-wrap items-center gap-3 rounded-xl border border-line bg-raised px-4 py-3 text-left transition hover:border-accent hover:bg-accent-wash"
              >
                <span className="w-14 font-mono text-sm font-bold text-ink">{b.symbol}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium text-ink">{naturalize(b.title)}</span>
                  <span className="text-xs text-ink-3" title={niceTimestamp(b.created_at)}>
                    Saved {timeAgo(b.created_at)}
                  </span>
                </span>
                <ModeBadge isFixture={b.is_fixture} />
                <StatusBadge status={b.report_status} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
