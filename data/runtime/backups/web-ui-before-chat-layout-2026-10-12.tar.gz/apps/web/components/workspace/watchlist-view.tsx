"use client";

import { useId, useState } from "react";

import type { WatchlistResponse } from "@/lib/api/types";
import { niceTimestamp, timeAgo } from "@/lib/natural";
import { useApi } from "@/lib/use-api";

import { ConfirmActionDialog, useProposal } from "../actions/confirm-action";
import { buttonClass, EmptyState, Notice, Spinner } from "../ui";
import { useWorkspace } from "./workspace-context";

/** Watchlist management (shown in a dialog). Every change asks for an explicit confirmation. */
export function WatchlistView() {
  const ws = useWorkspace();
  const { data, error, loading, reload } = useApi<WatchlistResponse>("/api/watchlist");
  const { pending, setPending, error: proposeError, propose, proposing } = useProposal();
  const [symbol, setSymbol] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const inputId = useId();

  function add(event: React.FormEvent) {
    event.preventDefault();
    setMessage(null);
    void propose("/api/watchlist", { method: "POST", json: { symbol: symbol.trim() } });
  }

  return (
    <div className="space-y-5">
      <form onSubmit={add} className="flex flex-wrap items-end gap-3">
        <div>
          <label htmlFor={inputId} className="block text-sm font-medium">
            Add a ticker
          </label>
          <input
            id={inputId}
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            maxLength={16}
            placeholder="AAPL"
            autoComplete="off"
            className="mt-1 w-40 rounded-lg border border-line bg-raised px-3 py-2 font-mono text-sm uppercase"
          />
        </div>
        <button type="submit" className={buttonClass.primary} disabled={proposing || !symbol.trim()}>
          {proposing ? "Checking…" : "Add to watchlist"}
        </button>
      </form>
      {proposeError && (
        <Notice tone="critical" title="Not added">
          {proposeError.message}
        </Notice>
      )}
      {message && <Notice title="Watchlist updated">{message}</Notice>}

      {loading && <Spinner label="Loading watchlist…" />}
      {error && <Notice tone="warning">{error.message}</Notice>}
      {data && data.items.length === 0 && <EmptyState title="Your watchlist is empty">Add a ticker above to follow it here.</EmptyState>}
      {data && data.items.length > 0 && (
        <ul className="divide-y divide-hairline rounded-xl border border-line bg-raised px-4">
          {data.items.map((item) => (
            <li key={item.symbol} className="flex flex-wrap items-center gap-3 py-3 text-sm">
              <span className="w-16 font-mono font-bold">{item.symbol}</span>
              <span className="min-w-0 flex-1 text-ink-2">{item.display_name ?? "—"}</span>
              <span className="text-xs text-ink-3" title={item.last_research_at ? niceTimestamp(item.last_research_at) : undefined}>
                {item.last_research_at ? `Researched ${timeAgo(item.last_research_at)}` : "Not researched yet"}
              </span>
              <button
                type="button"
                className={buttonClass.ghost}
                onClick={() => {
                  ws.prefill(item.symbol);
                  ws.closePanel();
                }}
              >
                Research
              </button>
              <button
                type="button"
                className={buttonClass.ghost}
                onClick={() => {
                  setMessage(null);
                  void propose(`/api/watchlist/${encodeURIComponent(item.symbol)}`, { method: "DELETE" });
                }}
                aria-label={`Remove ${item.symbol} from the watchlist`}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="text-xs text-ink-3">An app-local list of tickers you follow. It is never linked to a brokerage account.</p>

      {pending && (
        <ConfirmActionDialog
          action={pending}
          onClose={() => setPending(null)}
          onDone={(result) => {
            setPending(null);
            const r = result.result as Record<string, unknown>;
            setMessage(
              r["already_exists"]
                ? `${String(r["symbol"])} was already on your watchlist; nothing was duplicated.`
                : r["already_absent"]
                  ? `${String(r["symbol"])} was already removed.`
                  : r["removed"]
                    ? `${String(r["symbol"])} was removed.`
                    : `${String(r["symbol"])} was added.`,
            );
            setSymbol("");
            reload();
            ws.refresh();
          }}
        />
      )}
    </div>
  );
}
