"use client";

import { useStatus } from "../status-provider";
import { Notice } from "../ui";
import { useWorkspace } from "./workspace-context";

const QUICK_STARTS = [
  {
    symbol: "AAPL",
    title: "Explain recent movement",
    question:
      "Research AAPL over the last 3 months; explain notable movement; review recent news and latest available filings; list risks and unknowns.",
  },
  {
    symbol: "NVDA",
    title: "What changed recently?",
    question: "Give me a research briefing on Nvidia and explain what changed recently.",
  },
  {
    symbol: "MSFT",
    title: "Fundamentals and gaps",
    question: "Review Microsoft's latest reported fundamentals and filings, and state clearly what evidence is missing.",
  },
];

const STEPS = [
  { icon: "📥", title: "Gather", text: "Prices, SEC filings and dated news, fetched through three MCP servers." },
  { icon: "🧠", title: "Analyze", text: "Market, news and financials specialists draft findings; a supervisor writes the brief." },
  { icon: "🛡", title: "Fact-check", text: "Every number and date is checked against its source. Anything unsupported is set aside." },
];

/** What the main pane shows before a run or saved brief is opened. */
export function Welcome() {
  const ws = useWorkspace();
  const { health } = useStatus();
  const demo = health?.data_mode === "fixtures";
  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto max-w-3xl px-6 py-10 sm:py-14">
        <p className="text-xs font-semibold uppercase tracking-wider text-accent">Evidence-grounded equity research</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-ink sm:text-4xl">Research a US-listed company, with every claim checked.</h1>
        <p className="mt-3 max-w-2xl text-base leading-relaxed text-ink-2">
          Type a ticker in the bar above and ask what you want to know. MarketLens gathers the evidence, has specialist agents analyze it,
          and shows you what it found, what it couldn&apos;t find, and where every number came from.
        </p>
        {health?.warnings?.map((warning) => (
          <div key={warning} className="mt-4">
            <Notice tone="warning" title="Exposure warning">
              {warning}
            </Notice>
          </div>
        ))}
        {demo && (
          <div className="mt-5">
            <Notice title="Demo mode">
              Synthetic data for AAPL, MSFT and NVDA, dated through Sep 30, 2026. It is labeled everywhere and is never current market data.
            </Notice>
          </div>
        )}

        <h2 className="mt-10 text-sm font-semibold text-ink">Try one of these</h2>
        <ul className="mt-3 grid gap-3 sm:grid-cols-3">
          {QUICK_STARTS.map((q) => (
            <li key={q.title}>
              <button
                type="button"
                onClick={() => ws.prefill(q.symbol, q.question)}
                className="flex h-full w-full flex-col items-start rounded-2xl border border-line bg-surface p-4 text-left shadow-[0_1px_2px_rgba(0,0,0,0.04)] transition hover:-translate-y-0.5 hover:border-accent hover:shadow-md"
              >
                <span className="rounded-full bg-sunken px-2 py-0.5 font-mono text-xs font-bold text-ink-2">{q.symbol}</span>
                <span className="mt-2 block font-medium text-ink">{q.title}</span>
                <span className="mt-1 line-clamp-3 block text-xs leading-relaxed text-ink-3">{q.question}</span>
              </button>
            </li>
          ))}
        </ul>
        <p className="mt-2 text-xs text-ink-3">Fills in the research bar; nothing runs until you press Research.</p>

        <h2 className="mt-10 text-sm font-semibold text-ink">How it works</h2>
        <ol className="mt-3 grid gap-3 sm:grid-cols-3">
          {STEPS.map((step, i) => (
            <li key={step.title} className="rounded-2xl border border-line bg-surface p-4">
              <span aria-hidden="true" className="text-xl">
                {step.icon}
              </span>
              <p className="mt-2 font-medium text-ink">
                {i + 1}. {step.title}
              </p>
              <p className="mt-1 text-sm leading-relaxed text-ink-2">{step.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
