"use client";

import { useCallback, useEffect, useState } from "react";

import { Modal } from "../modal";
import { RunView } from "../run/run-view";
import { DataStatusView } from "../settings/data-status-view";
import { useStatus } from "../status-provider";
import { cn } from "../ui";
import { Rail } from "./rail";
import { ResearchBar } from "./research-bar";
import { SavedBriefView } from "./saved-brief-view";
import { SavedBriefsView } from "./saved-briefs-view";
import { WatchlistView } from "./watchlist-view";
import { Welcome } from "./welcome";
import { type Panel, type Preset, type Toast, type View, type WorkspaceApi, WorkspaceProvider } from "./workspace-context";

// Canonical copy (PROJECT_STATUS §2.5); mirrors marketlens_core.policy.RESEARCH_ONLY_NOTICE.
const RESEARCH_ONLY_DETAIL =
  "MarketLens does not place trades, connect to brokerage accounts, or provide personalized buy/sell recommendations. Content is informational, may be incomplete or delayed, and is not financial advice.";

export interface WorkspaceInitial {
  run?: string | null;
  brief?: string | null;
  panel?: Panel | null;
  symbol?: string | null;
}

function urlFor(view: View): string {
  if (!view) return "/";
  return view.kind === "run" ? `/?run=${encodeURIComponent(view.id)}` : `/?brief=${encodeURIComponent(view.id)}`;
}

function ModeBanner() {
  const { health, error, loading } = useStatus();
  if (loading) return null;
  if (error || !health) {
    return (
      <div className="border-b border-critical/40 bg-critical/10 px-4 py-1.5 text-center text-sm text-ink" role="alert">
        <strong>Backend unavailable.</strong> {error?.message ?? "Health check failed."}
      </div>
    );
  }
  if (health.data_mode === "fixtures") {
    return (
      <div className="border-b border-demo-border bg-demo-bg px-4 py-1 text-center text-xs text-demo-text" role="status" data-testid="demo-banner">
        <strong className="tracking-wide">DEMO FIXTURES</strong> — synthetic, illustrative data<span className="hidden sm:inline">. Not current market data</span>.
      </div>
    );
  }
  return (
    <div className="border-b border-good/40 bg-good/10 px-4 py-1 text-center text-xs font-medium text-good-text" role="status">
      LIVE DATA<span className="hidden sm:inline"> — values come from configured providers; check the as-of date on every section</span>
      <span className="sm:hidden"> — check each section&apos;s as-of date</span>
    </div>
  );
}

const PANELS: Record<Panel, { title: string; description?: string; size: "md" | "lg" | "xl" }> = {
  briefs: { title: "Saved briefs", description: "Snapshots keep their original sources, as-of dates and data mode.", size: "lg" },
  watchlist: { title: "Watchlist", description: "Every change asks for your confirmation first.", size: "lg" },
  status: { title: "Data status", description: "Modes, data sources, MCP servers and local usage.", size: "xl" },
  menu: { title: "Your research", size: "md" },
};

function ToastCard({ toast, onClose }: { toast: Toast; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 8000);
    return () => clearTimeout(timer);
  }, [toast, onClose]);
  return (
    <div role="status" className="fixed bottom-12 right-4 z-50 w-[min(22rem,calc(100vw-2rem))] rounded-2xl border border-line bg-surface p-4 shadow-2xl">
      <div className="flex items-start gap-3">
        <span aria-hidden="true" className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-good/15 text-sm font-bold text-good-text">
          ✓
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-medium text-ink">{toast.title}</p>
          {toast.body && <p className="mt-0.5 text-sm text-ink-2">{toast.body}</p>}
          {toast.action && (
            <button
              type="button"
              className="mt-2 text-sm font-medium text-accent hover:underline"
              onClick={() => {
                toast.action?.onClick();
                onClose();
              }}
            >
              {toast.action.label}
            </button>
          )}
        </div>
        <button type="button" onClick={onClose} aria-label="Dismiss" className="rounded px-1 text-ink-3 hover:text-ink">
          ×
        </button>
      </div>
    </div>
  );
}

/**
 * The whole app is this one screen. The research bar, run summary and side rail stay frozen;
 * only the brief scrolls. Lists and settings open as dialogs, and the URL is kept in sync
 * (?run= / ?brief=) without navigating, so refresh and sharing still work.
 */
export function Workspace({ initial }: { initial: WorkspaceInitial }) {
  const [view, setView] = useState<View>(
    initial.run ? { kind: "run", id: initial.run } : initial.brief ? { kind: "saved", id: initial.brief } : null,
  );
  const [panel, setPanel] = useState<Panel | null>(initial.panel ?? null);
  const [preset, setPreset] = useState<Preset | null>(initial.symbol ? { symbol: initial.symbol, nonce: 1 } : null);
  const [version, setVersion] = useState(0);
  const [toast, setToast] = useState<Toast | null>(null);
  const dismissToast = useCallback(() => setToast(null), []);

  function show(next: View) {
    setView(next);
    setPanel(null);
    window.history.replaceState(null, "", urlFor(next));
  }

  const workspace: WorkspaceApi = {
    view,
    openRun: (id) => show({ kind: "run", id }),
    openSaved: (id) => show({ kind: "saved", id }),
    goHome: () => show(null),
    openPanel: setPanel,
    closePanel: () => {
      setPanel(null);
      window.history.replaceState(null, "", urlFor(view));
    },
    prefill: (symbol, question) => setPreset((p) => ({ symbol, question, nonce: (p?.nonce ?? 0) + 1 })),
    preset,
    version,
    refresh: () => setVersion((v) => v + 1),
    notify: setToast,
  };

  const panelInfo = panel ? PANELS[panel] : null;
  const navButton = "rounded-lg px-2 py-1.5 text-sm font-medium text-ink-2 transition hover:bg-sunken hover:text-ink sm:px-3";

  return (
    <WorkspaceProvider value={workspace}>
      <div className="flex h-dvh flex-col overflow-hidden bg-plane">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-raised focus:px-3 focus:py-2"
        >
          Skip to content
        </a>
        <ModeBanner />
        <header className="border-b border-line bg-surface">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-2.5">
            <button type="button" onClick={workspace.goHome} className="flex shrink-0 items-center gap-2" aria-label="MarketLens home">
              <span aria-hidden="true" className="grid h-8 w-8 place-items-center rounded-lg bg-ink text-xs font-black text-plane">
                ML
              </span>
              <span className="hidden text-base font-semibold tracking-tight text-ink sm:inline">MarketLens</span>
            </button>
            <div className="order-last w-full md:order-none md:w-auto md:flex-1">
              <ResearchBar />
            </div>
            <nav aria-label="Workspace" className="ml-auto flex items-center gap-0.5">
              <button type="button" className={cn(navButton, "lg:hidden")} onClick={() => setPanel("menu")}>
                History
              </button>
              <button type="button" className={navButton} onClick={() => setPanel("briefs")}>
                Saved
              </button>
              <button type="button" className={navButton} onClick={() => setPanel("watchlist")}>
                Watchlist
              </button>
              <button type="button" className={navButton} onClick={() => setPanel("status")}>
                <span className="sm:hidden">Status</span>
                <span className="hidden sm:inline">Data status</span>
              </button>
            </nav>
          </div>
        </header>

        <div className="flex min-h-0 flex-1">
          <aside aria-label="Your research" className="hidden w-72 shrink-0 overflow-y-auto border-r border-line bg-surface lg:block">
            <Rail />
          </aside>
          <main id="main" className="flex min-w-0 flex-1 flex-col">
            {view === null && <Welcome />}
            {view?.kind === "run" && <RunView key={view.id} runId={view.id} />}
            {view?.kind === "saved" && <SavedBriefView key={view.id} briefId={view.id} />}
          </main>
        </div>

        <footer className="border-t border-line bg-surface px-4 py-1.5 text-[11px] leading-snug text-ink-3" data-testid="research-only-footer">
          <strong className="text-ink-2">Research only.</strong> <span className="sr-only sm:not-sr-only">{RESEARCH_ONLY_DETAIL}</span>
          <span aria-hidden="true" className="sm:hidden">
            No trades, no brokerage access, no personal buy/sell advice. Not financial advice.
          </span>
        </footer>

        {panel && panelInfo && (
          <Modal title={panelInfo.title} description={panelInfo.description} size={panelInfo.size} onClose={workspace.closePanel}>
            {panel === "briefs" && <SavedBriefsView />}
            {panel === "watchlist" && <WatchlistView />}
            {panel === "status" && <DataStatusView />}
            {panel === "menu" && <Rail />}
          </Modal>
        )}
        {toast && <ToastCard toast={toast} onClose={dismissToast} />}
      </div>
    </WorkspaceProvider>
  );
}

