"use client";

import { useState } from "react";

import { ApiError, api } from "@/lib/api/client";
import type { CreateResearchResponse, SavedBriefResponse } from "@/lib/api/types";
import { niceTimestamp, timeAgo } from "@/lib/natural";
import { useApi } from "@/lib/use-api";

import { BriefView } from "../run/brief-view";
import { BriefFrame, Headline, SummaryBar } from "../run/frame";
import { useEvidenceInspector } from "../run/use-inspector";
import { buttonClass, ModeBadge, Notice, Spinner, StatusBadge } from "../ui";
import { useWorkspace } from "./workspace-context";

const EMPTY: SavedBriefResponse["saved"]["evidence"] = [];
const NO_CLAIMS: SavedBriefResponse["saved"]["brief"]["claims"] = [];

export function SavedBriefView({ briefId }: { briefId: string }) {
  const ws = useWorkspace();
  const { data, error, loading } = useApi<SavedBriefResponse>(`/api/briefs/${briefId}`);
  const saved = data?.saved;
  const inspector = useEvidenceInspector(saved?.evidence ?? EMPTY, saved?.brief.claims ?? NO_CLAIMS);
  const [rerunError, setRerunError] = useState<string | null>(null);
  const [rerunning, setRerunning] = useState(false);

  if (loading) {
    return (
      <div className="grid flex-1 place-items-center">
        <Spinner label="Loading saved brief…" />
      </div>
    );
  }
  if (error || !saved) {
    return (
      <div className="mx-auto w-full max-w-2xl px-6 py-10">
        <Notice tone="critical" title={error?.code === "NOT_FOUND" ? "This saved brief doesn't exist" : "Couldn't load the saved brief"}>
          {error?.message}{" "}
          <button type="button" onClick={() => ws.openPanel("briefs")} className="font-medium text-accent underline">
            Show saved briefs
          </button>
        </Notice>
      </div>
    );
  }

  async function runAgain(runId: string) {
    setRerunning(true);
    setRerunError(null);
    try {
      const created = await api<CreateResearchResponse>(`/api/research/${runId}/rerun`, { method: "POST" });
      ws.refresh();
      ws.openRun(created.run.run_id);
    } catch (err) {
      setRerunError(err instanceof ApiError ? err.message : "Could not start the research again.");
      setRerunning(false);
    }
  }

  const bar = (
    <SummaryBar
      symbol={saved.symbol}
      company={saved.brief.company.company_name}
      badges={
        <>
          <span className="rounded-full border border-accent/40 bg-accent-wash px-2.5 py-0.5 text-xs font-semibold text-accent">Saved snapshot</span>
          <StatusBadge status={saved.report_status} />
          <ModeBadge isFixture={saved.is_fixture} />
        </>
      }
      actions={
        <>
          <button type="button" className={buttonClass.primarySm} disabled={rerunning} onClick={() => void runAgain(saved.run_id)}>
            {rerunning ? "Starting…" : (
              <>
                <span>Run again<span className="hidden sm:inline"> with fresh data</span></span>
              </>
            )}
          </button>
          <button type="button" className={buttonClass.secondarySm} onClick={() => ws.openRun(saved.run_id)}>
            Original run
          </button>
        </>
      }
      headline={<Headline brief={saved.brief} />}
      question={saved.brief.question}
    />
  );

  return (
    <BriefFrame bar={bar} side={inspector.panel}>
      <Notice title={`Saved ${timeAgo(saved.created_at)}`}>
        <span title={niceTimestamp(saved.created_at)}>
          This snapshot keeps the original sources, dates and data mode exactly as they were. It doesn&apos;t refresh: use “Run again with
          fresh data” for a new run. This snapshot stays as saved.
        </span>
      </Notice>
      {rerunError && <Notice tone="critical">{rerunError}</Notice>}
      <BriefView brief={saved.brief} evidence={inspector.evidence} selectedEvidence={inspector.selected} onSelectEvidence={inspector.select} />
    </BriefFrame>
  );
}
