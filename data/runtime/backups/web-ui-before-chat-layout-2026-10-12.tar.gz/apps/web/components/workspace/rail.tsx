"use client";

import { useCallback } from "react";

import type { BriefListResponse, RunList, RunStatus, WatchlistResponse } from "@/lib/api/types";
import { naturalize, niceTimestamp, timeAgo } from "@/lib/natural";
import { useApi, usePolling } from "@/lib/use-api";

import { cn, Notice, Spinner } from "../ui";
import { VoicePanel } from "../voice/voice-panel";
import { useWorkspace } from "./workspace-context";

const TERMINAL = new Set<RunStatus>(["completed", "partial", "failed", "cancelled"]);

const STATUS_DOT: Record<RunStatus, { dot: string; label: string }> = {
  queued: { dot: "bg-ink-3", label: "Queued" },
  running: { dot: "bg-accent animate-pulse", label: "Running" },
  completed: { dot: "bg-good", label: "Complete" },
  partial: { dot: "bg-warning", label: "Partial" },
  failed: { dot: "bg-critical", label: "Failed" },
  cancelled: { dot: "bg-ink-3", label: "Cancelled" },
};

function Heading({ title, action }: { title: string; action?: React.ReactNode }) {
  return (
    <div className="mb-1.5 flex items-center justify-between px-2">
      <h2 className="text-[11px] font-semibold uppercase tracking-wider text-ink-3">{title}</h2>
      {action}
    </div>
  );
}

function LinkButton({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} className="rounded px-1 text-xs font-medium text-accent hover:underline">
      {children}
    </button>
  );
}

function History() {
  const ws = useWorkspace();
  const isDone = useCallback((d: RunList) => d.runs.every((r) => TERMINAL.has(r.status)), []);
  // Refetched when the workspace changes, and polled while any listed run is still going.
  const { data, error, loading } = usePolling<RunList>(`/api/research?limit=15&v=${ws.version}`, isDone, 3000);
  const activeId = ws.view?.kind === "run" ? ws.view.id : null;
  return (
    <section aria-label="Research history">
      <Heading title="Research history" action={<LinkButton onClick={ws.goHome}>New</LinkButton>} />
      {loading && !data && <Spinner label="Loading…" />}
      {error && !data && <Notice tone="warning">{error.message}</Notice>}
      {data && data.runs.length === 0 && <p className="px-2 text-xs text-ink-3">Your research runs will appear here.</p>}
      {data && data.runs.length > 0 && (
        <ul className="space-y-0.5">
          {data.runs.map((run) => {
            const status = STATUS_DOT[run.status];
            const active = run.run_id === activeId;
            return (
              <li key={run.run_id}>
                <button
                  type="button"
                  onClick={() => ws.openRun(run.run_id)}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "w-full rounded-lg px-2 py-2 text-left transition",
                    active ? "bg-accent-wash ring-1 ring-accent/30" : "hover:bg-sunken",
                  )}
                >
                  <span className="flex items-center gap-2">
                    <span className="font-mono text-sm font-bold text-ink">{run.symbol}</span>
                    <span className="inline-flex items-center gap-1 text-[11px] text-ink-3">
                      <span aria-hidden="true" className={cn("h-1.5 w-1.5 rounded-full", status.dot)} />
                      {status.label}
                    </span>
                    {run.data_mode === "fixture" && <span className="rounded bg-demo-bg px-1 text-[10px] font-semibold text-demo-text">DEMO</span>}
                    <span className="ml-auto text-[11px] text-ink-3" title={niceTimestamp(run.created_at)}>
                      {timeAgo(run.created_at)}
                    </span>
                  </span>
                  <span className="mt-0.5 line-clamp-2 block text-xs leading-snug text-ink-2">{run.question}</span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function Watchlist() {
  const ws = useWorkspace();
  const { data, error } = useApi<WatchlistResponse>(`/api/watchlist?v=${ws.version}`);
  return (
    <section aria-label="Watchlist">
      <Heading title="Watchlist" action={<LinkButton onClick={() => ws.openPanel("watchlist")}>Manage</LinkButton>} />
      {error && <p className="px-2 text-xs text-critical-text">{error.message}</p>}
      {data && data.items.length === 0 && <p className="px-2 text-xs text-ink-3">Follow tickers here. Add them under Manage.</p>}
      {data && data.items.length > 0 && (
        <ul className="flex flex-wrap gap-1.5 px-2">
          {data.items.map((item) => (
            <li key={item.symbol}>
              <button
                type="button"
                onClick={() => ws.prefill(item.symbol)}
                title={`Research ${item.display_name ?? item.symbol}`}
                className="rounded-full border border-line bg-raised px-2.5 py-1 font-mono text-xs font-semibold text-ink transition hover:border-accent hover:text-accent"
              >
                {item.symbol}
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Saved() {
  const ws = useWorkspace();
  const { data, error } = useApi<BriefListResponse>(`/api/briefs?limit=6&v=${ws.version}`);
  const activeId = ws.view?.kind === "saved" ? ws.view.id : null;
  return (
    <section aria-label="Saved briefs">
      <Heading title="Saved briefs" action={<LinkButton onClick={() => ws.openPanel("briefs")}>All</LinkButton>} />
      {error && <p className="px-2 text-xs text-critical-text">{error.message}</p>}
      {data && data.briefs.length === 0 && <p className="px-2 text-xs text-ink-3">Save a finished brief to keep it with its original sources.</p>}
      {data && data.briefs.length > 0 && (
        <ul className="space-y-0.5">
          {data.briefs.map((b) => (
            <li key={b.brief_id}>
              <button
                type="button"
                onClick={() => ws.openSaved(b.brief_id)}
                aria-current={b.brief_id === activeId ? "page" : undefined}
                className={cn(
                  "w-full rounded-lg px-2 py-1.5 text-left transition",
                  b.brief_id === activeId ? "bg-accent-wash ring-1 ring-accent/30" : "hover:bg-sunken",
                )}
              >
                <span className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-ink">{b.symbol}</span>
                  <span className="ml-auto text-[11px] text-ink-3">saved {timeAgo(b.created_at)}</span>
                </span>
                <span className="block truncate text-xs text-ink-2">{naturalize(b.title.replace(/^[A-Z.]+ — /, ""))}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

/** The workspace side rail: history, watchlist, saved briefs and voice. */
export function Rail() {
  return (
    <div className="space-y-6 px-2 py-4">
      <History />
      <Watchlist />
      <Saved />
      <div className="px-2">
        <VoicePanel />
      </div>
    </div>
  );
}
