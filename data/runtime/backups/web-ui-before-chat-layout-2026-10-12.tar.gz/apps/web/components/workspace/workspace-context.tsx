"use client";

import { createContext, useContext } from "react";

/** What the main pane shows: a research run, a saved snapshot, or the welcome screen. */
export type View = { kind: "run"; id: string } | { kind: "saved"; id: string } | null;

/** Secondary content that opens in a modal over the workspace. */
export type Panel = "briefs" | "watchlist" | "status" | "menu";

export interface Preset {
  symbol: string;
  question?: string;
  nonce: number;
}

export interface Toast {
  title: string;
  body?: string;
  action?: { label: string; onClick: () => void };
}

export interface WorkspaceApi {
  view: View;
  openRun: (runId: string) => void;
  openSaved: (briefId: string) => void;
  goHome: () => void;
  openPanel: (panel: Panel) => void;
  closePanel: () => void;
  /** Fill the research bar (e.g. from the watchlist) without starting anything. */
  prefill: (symbol: string, question?: string) => void;
  preset: Preset | null;
  /** Bumped when runs, saved briefs or the watchlist change, so side lists refetch. */
  version: number;
  refresh: () => void;
  notify: (toast: Toast) => void;
}

const WorkspaceContext = createContext<WorkspaceApi | null>(null);

export const WorkspaceProvider = WorkspaceContext.Provider;

export function useWorkspace(): WorkspaceApi {
  const value = useContext(WorkspaceContext);
  if (!value) throw new Error("useWorkspace must be used inside <Workspace>.");
  return value;
}
