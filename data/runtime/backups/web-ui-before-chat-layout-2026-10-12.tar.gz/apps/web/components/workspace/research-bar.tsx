"use client";

import { useEffect, useId, useRef, useState } from "react";

import { api, ApiError } from "@/lib/api/client";
import type { CreateResearchResponse, ResearchRequest } from "@/lib/api/types";

import { useStatus } from "../status-provider";
import { buttonClass, cn } from "../ui";
import { useWorkspace } from "./workspace-context";

type HorizonChoice = "default" | "1m" | "6m" | "1y" | "custom";

/** Used when the question box is left empty, so a ticker alone is enough to start. */
const DEFAULT_QUESTION = "Review recent price movement, company fundamentals, news context and key risks.";

/**
 * The research bar stays frozen at the top of the workspace: a new question can be asked from
 * anywhere, and starting one opens the run in place instead of navigating to another page.
 */
export function ResearchBar() {
  const ws = useWorkspace();
  const { health } = useStatus();
  const ids = { symbol: useId(), question: useId(), horizon: useId(), start: useId(), end: useId(), error: useId() };
  const questionRef = useRef<HTMLInputElement>(null);
  const [symbol, setSymbol] = useState(ws.preset?.symbol ?? "");
  const [question, setQuestion] = useState(ws.preset?.question ?? "");
  const [seenPreset, setSeenPreset] = useState(ws.preset?.nonce ?? 0);
  const [horizon, setHorizon] = useState<HorizonChoice>("default");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);

  // Apply a new preset (watchlist chip, quick start) during render; no effect needed for state.
  if (ws.preset && ws.preset.nonce !== seenPreset) {
    setSeenPreset(ws.preset.nonce);
    setSymbol(ws.preset.symbol);
    if (ws.preset.question !== undefined) setQuestion(ws.preset.question);
    setError(null);
  }
  // ...and move focus to the question so the user can type or just press Enter.
  const presetNonce = ws.preset?.nonce;
  useEffect(() => {
    if (presetNonce) questionRef.current?.focus();
  }, [presetNonce]);

  const fixtureMode = health?.data_mode === "fixtures";

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    const body: ResearchRequest = {
      symbol: symbol.trim(),
      question: question.trim() || DEFAULT_QUESTION,
      client_request_id: crypto.randomUUID().replace(/-/g, "").slice(0, 32),
    };
    if (horizon === "custom") body.time_horizon = { start_date: start || null, end_date: end || null };
    else if (horizon !== "default") body.time_horizon = { preset: horizon };
    try {
      const created = await api<CreateResearchResponse>("/api/research", { method: "POST", json: body });
      ws.refresh();
      ws.openRun(created.run.run_id);
    } catch (err) {
      setError(err instanceof ApiError ? err : new ApiError("UNKNOWN", "The request failed.", 0));
    } finally {
      setSubmitting(false);
    }
  }

  const fieldIssue = error?.fieldIssues.map((f) => f.issue).join(" ");
  const problem = error ? `${error.message}${fieldIssue ? ` ${fieldIssue}` : ""}` : null;
  const symbolProblem = Boolean(error && ["INVALID_SYMBOL", "UNKNOWN_SYMBOL"].includes(error.code));

  return (
    <form onSubmit={submit} noValidate aria-label="New research" className="min-w-0">
      <div className="flex flex-wrap items-center gap-1.5 rounded-xl border border-line bg-raised p-1.5 shadow-sm focus-within:border-accent focus-within:ring-2 focus-within:ring-accent/25">
        <label htmlFor={ids.symbol} className="sr-only">
          Ticker
        </label>
        <input
          id={ids.symbol}
          value={symbol}
          onChange={(e) => setSymbol(e.target.value.toUpperCase())}
          maxLength={16}
          autoComplete="off"
          spellCheck={false}
          placeholder={fixtureMode ? "AAPL" : "Ticker"}
          aria-invalid={symbolProblem}
          aria-describedby={problem ? ids.error : undefined}
          className={cn(
            "w-24 rounded-lg bg-sunken px-3 py-2 font-mono text-sm font-semibold uppercase tracking-wide text-ink placeholder:font-normal placeholder:normal-case placeholder:text-ink-3 focus-visible:outline-none",
            symbolProblem && "ring-1 ring-critical",
          )}
        />
        <label htmlFor={ids.question} className="sr-only">
          Research question
        </label>
        <input
          id={ids.question}
          ref={questionRef}
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          maxLength={1000}
          placeholder="What do you want to know? e.g. why did the price move, and what are the risks?"
          className="min-w-[12rem] flex-1 bg-transparent px-2 py-2 text-sm text-ink placeholder:text-ink-3 focus-visible:outline-none"
        />
        <label htmlFor={ids.horizon} className="sr-only">
          Time horizon
        </label>
        <select
          id={ids.horizon}
          value={horizon}
          onChange={(e) => setHorizon(e.target.value as HorizonChoice)}
          className="rounded-lg bg-sunken px-2 py-2 text-sm text-ink-2 focus-visible:outline-none"
        >
          <option value="default">3 months</option>
          <option value="1m">1 month</option>
          <option value="6m">6 months</option>
          <option value="1y">12 months</option>
          <option value="custom">Custom dates…</option>
        </select>
        <button type="submit" className={cn(buttonClass.primary, "py-2")} disabled={submitting || !symbol.trim()}>
          {submitting ? "Starting…" : "Research"}
        </button>
      </div>
      {horizon === "custom" && (
        <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-ink-2">
          <label htmlFor={ids.start}>From</label>
          <input id={ids.start} type="date" value={start} onChange={(e) => setStart(e.target.value)} className="rounded-lg border border-line bg-raised px-2 py-1" />
          <label htmlFor={ids.end}>to</label>
          <input id={ids.end} type="date" value={end} onChange={(e) => setEnd(e.target.value)} className="rounded-lg border border-line bg-raised px-2 py-1" />
        </div>
      )}
      {problem && (
        <p id={ids.error} role="alert" className="mt-1.5 text-xs text-critical-text">
          {problem}
          {error?.requestId && <span className="text-ink-3"> · request {error.requestId}</span>}
        </p>
      )}
    </form>
  );
}
