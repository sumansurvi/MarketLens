"use client";

import {
  type ReceivedMessage,
  RoomAudioRenderer,
  SessionProvider,
  StartAudio,
  useAgent,
  useSession,
  useSessionMessages,
} from "@livekit/components-react";
import { ConnectionState, TokenSource } from "livekit-client";
import { useCallback, useEffect, useRef, useState } from "react";

import { ApiError, api } from "@/lib/api/client";
import type { VoiceSessionResponse, VoiceSessionState } from "@/lib/api/types";

import { useStatus } from "../status-provider";
import { buttonClass, Card, cn } from "../ui";
import { useWorkspace } from "../workspace/workspace-context";
import { liveState, STATE_COPY, type VoiceUiState } from "./voice-state";

type FailureReason = "permission_denied" | "unreachable" | "agent_failed" | "agent_left" | "rate_limited" | "other";
type Outcome = { state: "permission_denied" | "error" | "ended"; message: string; reason?: FailureReason } | null;

const AGENT_JOIN_TIMEOUT_MS = 20_000;
// Codes the voice worker publishes in the `marketlens.voice_error` participant attribute.
const AGENT_STOP_REASONS: Record<string, string> = {
  speech_recognition_unavailable: "The voice assistant could not reach its speech-recognition service (check LiveKit Inference and VOICE_STT_MODEL).",
  speech_output_unavailable: "The voice assistant could not reach its speech-output service (check LiveKit Inference and VOICE_TTS_MODEL).",
  voice_model_unavailable: "The voice assistant could not reach its language model (check LiveKit Inference and VOICE_LLM_MODEL).",
  voice_pipeline_error: "The voice assistant stopped after an error.",
};
const RUN_POLL_MS = 2_500;
const TEXT_FALLBACK = "Prefer typing? The research bar at the top runs the same workflow.";

/** Home-page voice card: setup guidance when voice is off, otherwise an explicit start. */
export function VoicePanel() {
  const { health } = useStatus();
  if (!health) return null;
  if (!health.voice_enabled) return <VoiceDisabled />;
  return <VoiceLauncher />;
}

function VoiceDisabled() {
  return (
    <div className="flex items-start gap-3 rounded-xl border border-dashed border-baseline p-3">
      <span aria-hidden="true" className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-sunken text-ink-3">
        🎙
      </span>
      <div className="text-xs leading-relaxed text-ink-3" data-testid="voice-state" data-state="disabled">
        <p className="text-sm font-medium text-ink-2">Voice not configured</p>
        <p className="mt-0.5">
          Text research works fully without it. To turn voice on, see README › Configuration › Voice.
        </p>
      </div>
    </div>
  );
}

async function checkMicrophone(): Promise<Outcome> {
  if (!navigator.mediaDevices?.getUserMedia) {
    return {
      state: "error",
      message: "This browser does not allow microphone access on this page. Use a current browser on http://localhost or https.",
    };
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((track) => track.stop());
    return null;
  } catch (err) {
    const name = err instanceof DOMException ? err.name : "";
    if (name === "NotAllowedError" || name === "SecurityError" || name === "PermissionDeniedError") {
      return {
        state: "permission_denied",
        message: "Microphone access was blocked. Allow it in the browser's site settings and press Start again, or type your question in the research bar.",
      };
    }
    if (name === "NotFoundError" || name === "OverconstrainedError") {
      return { state: "error", message: "No microphone was found. Connect one and try again, or use the research bar." };
    }
    return { state: "error", message: "The microphone could not be started. Try again, or use the research bar." };
  }
}

function describe(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  return "Could not connect to the voice service. Check that LiveKit is reachable and the voice worker is running, or use the research bar.";
}

/** Local analytics (coded outcome only; nothing else about the session is reported). */
function reportVoice(event: "voice_connection_succeeded" | "voice_connection_failed", reason?: FailureReason): void {
  void api("/api/analytics/events", { method: "POST", json: reason ? { event, reason } : { event } }).catch(() => undefined);
}

function endBackendSession(room: string | null): Promise<unknown> {
  if (!room) return Promise.resolve();
  return api(`/api/voice/session/${room}/end`, { method: "POST" }).catch(() => undefined);
}

function VoiceLauncher() {
  const [attempt, setAttempt] = useState(0);
  const [live, setLive] = useState(false);
  const [checking, setChecking] = useState(false);
  const [outcome, setOutcome] = useState<Outcome>(null);

  const start = async () => {
    setOutcome(null);
    setChecking(true);
    const problem = await checkMicrophone();
    setChecking(false);
    if (problem) {
      reportVoice("voice_connection_failed", problem.state === "permission_denied" ? "permission_denied" : "other");
      setOutcome(problem);
      return;
    }
    setAttempt((n) => n + 1);
    setLive(true);
  };
  const close = useCallback((result: Outcome) => {
    setLive(false);
    setOutcome(result);
  }, []);

  const idleState: VoiceUiState = outcome?.state ?? "ready";
  return (
    <Card title="Voice" description="Ask by voice and hear a short summary; the full cited report opens on screen.">
      {live ? (
        <LiveVoiceSession key={attempt} onClose={close} />
      ) : (
        <div className="space-y-3">
          <StatusLine state={idleState} detail={outcome?.message} />
          <button type="button" onClick={start} disabled={checking} className={buttonClass.primary}>
            {checking ? "Checking microphone…" : outcome ? "Start a new voice session" : "Start voice session"}
          </button>
        </div>
      )}
      <p className="mt-3 text-xs text-ink-3">{TEXT_FALLBACK}</p>
    </Card>
  );
}

function StatusLine({ state, detail, muted }: { state: VoiceUiState; detail?: string; muted?: boolean }) {
  const copy = STATE_COPY[state];
  const dot = {
    idle: "bg-baseline",
    active: "bg-accent animate-pulse",
    warning: "bg-warning",
    critical: "bg-critical",
  }[copy.tone];
  return (
    <div role="status" aria-live="polite" data-testid="voice-state" data-state={state} className="flex items-start gap-2.5">
      <span aria-hidden="true" className={cn("mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full", dot)} />
      <div className="text-sm">
        <p className="font-medium text-ink">
          {copy.label}
          {muted ? " · microphone muted" : ""}
        </p>
        {(detail || copy.detail) && <p className="mt-0.5 text-ink-2">{detail || copy.detail}</p>}
      </div>
    </div>
  );
}

/** The voice-started run for this room, polled while connected (null until research starts). */
function useVoiceRun(room: string | null, connected: boolean): VoiceSessionState | null {
  const [state, setState] = useState<VoiceSessionState | null>(null);
  useEffect(() => {
    if (!connected || !room) return;
    let stopped = false;
    const tick = async () => {
      try {
        const next = await api<VoiceSessionState>(`/api/voice/session/${room}`);
        if (!stopped) setState(next);
      } catch {
        // Transient; the next poll retries. The run itself lives on the server.
      }
    };
    void tick();
    const timer = setInterval(tick, RUN_POLL_MS);
    return () => {
      stopped = true;
      clearInterval(timer);
    };
  }, [connected, room]);
  return state;
}

function LiveVoiceSession({ onClose }: { onClose: (outcome: Outcome) => void }) {
  const { openRun } = useWorkspace();
  const [room, setRoom] = useState<string | null>(null);
  // One voice room per attempt: the SDK fetches credentials on mount, on start and again (forced)
  // on end or disconnect to pre-warm a new room; every fetch here returns this attempt's grant.
  const [voice] = useState(() => {
    let grant: Promise<VoiceSessionResponse> | null = null;
    return {
      tokenSource: TokenSource.custom(async () => {
        grant ??= api<VoiceSessionResponse>("/api/voice/session", { method: "POST" });
        const value = await grant;
        setRoom(value.room_name);
        return { serverUrl: value.server_url, participantToken: value.participant_token };
      }),
      /** Mark this attempt's room ended on the server (nothing to do if no room was created). */
      async end(): Promise<void> {
        const value = grant ? await grant.catch(() => null) : null;
        if (value) await endBackendSession(value.room_name);
      },
    };
  });
  const session = useSession(voice.tokenSource, { agentConnectTimeoutMilliseconds: AGENT_JOIN_TIMEOUT_MS });
  const agent = useAgent(session);
  const { messages } = useSessionMessages(session);
  const run = useVoiceRun(room, session.isConnected);
  const [muted, setMuted] = useState(false);
  const started = useRef(false);
  const connectedOnce = useRef(false);
  const closing = useRef(false);

  const finish = useCallback(
    (outcome: Outcome) => {
      if (closing.current) return;
      closing.current = true;
      if (outcome?.state === "error") reportVoice("voice_connection_failed", outcome.reason ?? "other");
      void session.end();
      void voice.end();
      onClose(outcome);
    },
    [session, voice, onClose],
  );

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    session.start({ tracks: { microphone: { enabled: true } } }).catch((err: unknown) => {
      const reason = err instanceof ApiError && err.code === "RATE_LIMITED" ? "rate_limited" : "unreachable";
      finish({ state: "error", message: describe(err), reason });
    });
  }, [session, finish]);

  useEffect(() => {
    if (session.connectionState === ConnectionState.Connected) connectedOnce.current = true;
    if (connectedOnce.current && session.connectionState === ConnectionState.Disconnected) {
      finish({
        state: "error",
        message: "The voice connection was lost. Research already started keeps running; open it from your research history, or start a new voice session.",
        reason: "unreachable",
      });
    }
  }, [session.connectionState, finish]);

  const agentJoined = useRef(false);
  const agentStopCode = useRef<string | null>(null);
  useEffect(() => {
    if (agent.isConnected && !agentJoined.current) {
      agentJoined.current = true;
      reportVoice("voice_connection_succeeded");
    }
    const code = "attributes" in agent ? agent.attributes?.["marketlens.voice_error"] : undefined;
    if (code) agentStopCode.current = code;
    const left = agent.state === "disconnected" && session.connectionState === ConnectionState.Connected;
    if (agentJoined.current && (left || agentStopCode.current)) {
      const reason = AGENT_STOP_REASONS[agentStopCode.current ?? ""] ?? "The voice assistant left the session unexpectedly.";
      finish({
        state: "error",
        message: `${reason} Research already started keeps running, and text research still works.`,
        reason: "agent_left",
      });
    }
  }, [agent, session.connectionState, finish]);

  useEffect(() => {
    if (agent.state === "failed") {
      const reasons = agent.failureReasons?.join(" ") || "The voice assistant did not join.";
      finish({
        state: "error",
        message: `${reasons} Check that the voice worker is running (see README), or use the research bar.`,
        reason: "agent_failed",
      });
    }
  }, [agent.state, agent.failureReasons, finish]);

  const toggleMute = async () => {
    const next = !muted;
    await session.room.localParticipant.setMicrophoneEnabled(!next);
    setMuted(next);
  };

  const researchRunning = run?.active_run_status === "queued" || run?.active_run_status === "running";
  const state = liveState(session.connectionState, agent.state, researchRunning);

  return (
    <SessionProvider session={session}>
      <div className="space-y-3">
        <StatusLine state={state} muted={muted} />
        {run?.active_run_id && (
          <p className="text-sm">
            <button type="button" onClick={() => openRun(run.active_run_id ?? "")} className="font-medium text-accent underline-offset-2 hover:underline">
              {researchRunning ? "Follow the research run" : "Open the full report"}
            </button>
            {run.active_run_status && !researchRunning && <span className="text-ink-3"> · {run.active_run_status}</span>}
          </p>
        )}
        <Transcript messages={messages} />
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={toggleMute} aria-pressed={muted} className={buttonClass.secondary} disabled={!session.isConnected}>
            {muted ? "Unmute microphone" : "Mute microphone"}
          </button>
          <button
            type="button"
            onClick={() => finish({ state: "ended", message: "Voice session ended. Reports stay in your research history." })}
            className={buttonClass.secondary}
          >
            End session
          </button>
          <StartAudio label="Allow audio playback" className={buttonClass.secondary} />
        </div>
        <p className="text-xs text-ink-3">The transcript is shown live and is not stored. The assistant cannot save briefs or change your watchlist; use the buttons on screen.</p>
        <RoomAudioRenderer />
      </div>
    </SessionProvider>
  );
}

function speaker(message: ReceivedMessage): string {
  if (message.type === "userTranscript") return "You";
  if (message.type === "agentTranscript") return "MarketLens";
  return message.from?.isLocal ? "You" : "MarketLens";
}

function Transcript({ messages }: { messages: ReceivedMessage[] }) {
  const recent = messages.slice(-8);
  if (recent.length === 0) {
    return <p className="text-xs text-ink-3">Try: “Research Apple, ticker A A P L, over the last three months.”</p>;
  }
  return (
    <ol aria-label="Live transcript" aria-live="polite" className="max-h-56 space-y-1.5 overflow-y-auto rounded-md border border-line bg-sunken px-3 py-2 text-sm">
      {recent.map((message) => (
        <li key={message.id}>
          <span className="text-xs font-semibold text-ink-3">{speaker(message)}: </span>
          <span className="text-ink">{message.message}</span>
        </li>
      ))}
    </ol>
  );
}
