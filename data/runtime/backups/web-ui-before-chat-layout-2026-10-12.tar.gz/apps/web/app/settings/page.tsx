import type { Metadata } from "next";

import { Workspace } from "@/components/workspace/workspace";

export const metadata: Metadata = { title: "Data status" };

// Kept so existing links keep working: opens the workspace with the data-status dialog.
export default function SettingsPage() {
  return <Workspace initial={{ panel: "status" }} />;
}
