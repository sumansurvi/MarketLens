import type { Metadata } from "next";

import { Workspace } from "@/components/workspace/workspace";

export const metadata: Metadata = { title: "Watchlist" };

// Kept so existing links keep working: opens the workspace with the watchlist dialog.
export default function WatchlistPage() {
  return <Workspace initial={{ panel: "watchlist" }} />;
}
