import type { Metadata } from "next";

import { Workspace } from "@/components/workspace/workspace";

export const metadata: Metadata = { title: "Saved briefs" };

// Kept so existing links keep working: opens the workspace with the saved-briefs dialog.
export default function BriefsPage() {
  return <Workspace initial={{ panel: "briefs" }} />;
}
