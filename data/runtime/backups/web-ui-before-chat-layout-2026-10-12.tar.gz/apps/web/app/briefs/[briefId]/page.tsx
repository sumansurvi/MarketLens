import { Suspense } from "react";

import { Workspace } from "@/components/workspace/workspace";

// Kept so existing links keep working: the snapshot opens inside the single-page workspace.
export default function SavedBriefPage({ params }: PageProps<"/briefs/[briefId]">) {
  return (
    <Suspense fallback={<div className="h-dvh bg-plane" />}>
      {params.then(({ briefId }) => (
        <Workspace initial={{ brief: briefId }} />
      ))}
    </Suspense>
  );
}
